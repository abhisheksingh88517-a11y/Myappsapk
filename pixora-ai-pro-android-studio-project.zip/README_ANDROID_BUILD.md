# PIXORA AI Pro — Complete Android Build Guide

Package: `ai.pixora.photoeditor`
Version: `2.4.0` (Code 24)
Target SDK: `34` (Android 14) | Min SDK: `24` (Android 7.0+)

---

## 📱 How to Build APK Directly on Your Phone (Using GitHub Mobile Web)

You do **not** need a computer to build the APK! You can use GitHub's free cloud runners directly from your Android phone's web browser:

1. **Step 1: Download & Extract this ZIP**
   - Download `pixora-ai-pro-android-studio-project.zip` to your phone's Downloads.
   - Use your phone's Files app to extract the folder.

2. **Step 2: Create a New GitHub Repository**
   - Open [github.com](https://github.com) on your phone in Chrome or Firefox.
   - Tap **New Repository** (e.g. name it `pixora-photo-editor`). Choose Public or Private.

3. **Step 3: Upload the Project Files**
   - On the new repository page, tap **"uploading an existing file"**.
   - Select the files from the extracted folder (make sure `.github/workflows/build-apk.yml` and all folders are included).
   - Tap **Commit changes**.

4. **Step 4: Watch GitHub Actions Build the APK**
   - Tap the **Actions** tab on your GitHub repository.
   - You will see the **"Build PIXORA AI Android APK"** workflow running on an Ubuntu cloud server with Android SDK 34 and JDK 17 pre-installed!
   - In approximately 2 minutes, the workflow turns green (Passed ✅).

5. **Step 5: Download & Install the APK**
   - Tap on the completed build run.
   - Under **Artifacts** at the bottom, tap **`PIXORA-AI-Photo-Editor-v2.4.0.apk`**.
   - Chrome will download the APK file directly to your phone.
   - Tap the downloaded APK to install PIXORA AI!

---

## 💻 Building on a Computer with Android Studio

1. Extract the ZIP.
2. Open **Android Studio** and choose **Open**.
3. Select this folder and wait for Gradle sync.
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The APK will be ready at:
   `app/build/outputs/apk/debug/app-debug.apk`

---

## ⚡ Terminal Build Command (Mac/Linux/Windows)

```bash
chmod +x ./gradlew
./gradlew assembleDebug
```
