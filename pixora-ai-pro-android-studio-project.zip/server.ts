import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));

// Initialize Gemini SDK with telemetry header
const apiKey = process.env.GEMINI_API_KEY || '';
const hasGeminiKey = Boolean(apiKey && apiKey !== 'MY_GEMINI_API_KEY' && apiKey.trim().length > 0);

let ai: GoogleGenAI | null = null;
if (hasGeminiKey) {
  try {
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } catch (err) {
    console.error('Failed to initialize GoogleGenAI client:', err);
  }
}

// Health & Status endpoint
app.get('/api/status', (_req, res) => {
  res.json({
    status: 'online',
    appName: 'PIXORA AI — AI Photo Editor Pro',
    version: '2.4.0',
    geminiConfigured: hasGeminiKey,
    deviceCapabilities: {
      webgl2: true,
      webgpu: false,
      clientProcessing: 'GPU Canvas + Three.js PBR',
      exportFormats: ['image/jpeg', 'image/png', 'image/webp'],
    },
  });
});

// AI Editing Assistant endpoint
app.post('/api/ai/assistant', async (req, res) => {
  const { prompt, currentAdjustments } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  if (!ai || !hasGeminiKey) {
    // Provide intelligent deterministic fallback if API key is not configured
    const lower = prompt.toLowerCase();
    let adjustments = { ...(currentAdjustments || {}) };
    let filter = 'Original';
    let explanation = 'Applied local smart presets based on your natural language request.';

    if (lower.includes('cinematic') || lower.includes('movie') || lower.includes('film')) {
      filter = 'Cinematic Teal';
      adjustments = {
        ...adjustments,
        contrast: 22,
        saturation: -5,
        temperature: -10,
        tint: 8,
        highlights: -15,
        shadows: 18,
        vignette: 28,
        grain: 15,
        sharpness: 25,
      };
      explanation = 'Adjusted contrast, muted saturation, balanced teal-orange tone curves, and added cinematic vignette.';
    } else if (lower.includes('warm') || lower.includes('sunset') || lower.includes('golden')) {
      filter = 'Golden Hour';
      adjustments = {
        ...adjustments,
        exposure: 8,
        temperature: 28,
        tint: 12,
        highlights: -10,
        shadows: 14,
        vibrance: 20,
        vignette: 15,
      };
      explanation = 'Shifted color balance towards warm golden amber tones and lifted warm highlights.';
    } else if (lower.includes('bright') || lower.includes('light') || lower.includes('face')) {
      filter = 'Portrait Soft';
      adjustments = {
        ...adjustments,
        exposure: 18,
        brightness: 12,
        contrast: -6,
        shadows: 24,
        whites: 10,
        clarity: 15,
      };
      explanation = 'Lifted midtone exposure and softened deep shadows for glowing, flattering lighting.';
    } else if (lower.includes('vintage') || lower.includes('retro') || lower.includes('old')) {
      filter = 'Vintage Amber';
      adjustments = {
        ...adjustments,
        contrast: 15,
        saturation: -18,
        temperature: 20,
        fade: 24,
        grain: 32,
        vignette: 30,
      };
      explanation = 'Infused analogue grain, lifted blacks with film fade, and mellowed saturation.';
    } else if (lower.includes('bw') || lower.includes('black and white') || lower.includes('monochrome')) {
      filter = 'B&W Dramatic';
      adjustments = {
        ...adjustments,
        saturation: -100,
        contrast: 35,
        highlights: 15,
        shadows: -15,
        clarity: 30,
        grain: 18,
      };
      explanation = 'Stripped all color channels and pushed high-contrast monochrome silver tones.';
    } else {
      adjustments = {
        ...adjustments,
        exposure: 10,
        contrast: 15,
        vibrance: 15,
        clarity: 20,
        sharpness: 20,
      };
      explanation = 'Enhanced photo dynamics: auto-balanced contrast, boosted natural vibrance, and increased clarity.';
    }

    return res.json({
      adjustments,
      filter,
      explanation,
      mode: 'smart-local-rule-engine',
    });
  }

  try {
    const systemPrompt = `You are Pixora AI Pro's photo grading engine. Convert the user's natural language photo editing request into numerical adjustment parameters between -100 and +100 (exposure between -50 and 50).
Output strictly in JSON matching the schema.
Known filters: "Original", "Cinematic Teal", "Golden Hour", "Vintage Amber", "Moody Noir", "B&W Dramatic", "Cyberpunk Neon", "Portrait Soft", "Emerald Forest", "Sunset Glow", "Vivid Pop", "Matte Editorial".`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `User request: "${prompt}". Current adjustments: ${JSON.stringify(currentAdjustments || {})}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            filter: { type: Type.STRING },
            explanation: { type: Type.STRING },
            adjustments: {
              type: Type.OBJECT,
              properties: {
                brightness: { type: Type.NUMBER },
                exposure: { type: Type.NUMBER },
                contrast: { type: Type.NUMBER },
                saturation: { type: Type.NUMBER },
                vibrance: { type: Type.NUMBER },
                temperature: { type: Type.NUMBER },
                tint: { type: Type.NUMBER },
                highlights: { type: Type.NUMBER },
                shadows: { type: Type.NUMBER },
                clarity: { type: Type.NUMBER },
                sharpness: { type: Type.NUMBER },
                vignette: { type: Type.NUMBER },
                grain: { type: Type.NUMBER },
                fade: { type: Type.NUMBER },
              },
            },
          },
          required: ['filter', 'explanation', 'adjustments'],
        },
      },
    });

    const parsed = JSON.parse(response.text?.trim() || '{}');
    return res.json({
      ...parsed,
      mode: 'gemini-3.8-flash',
    });
  } catch (error: any) {
    console.error('Gemini Assistant Error, using resilient rule engine:', error);
    // Intelligent deterministic fallback
    const lower = prompt.toLowerCase();
    let adjustments = { ...(currentAdjustments || {}) };
    let filter = 'Original';
    let explanation = 'Applied local smart presets based on your natural language request.';

    if (lower.includes('cinematic') || lower.includes('movie') || lower.includes('film')) {
      filter = 'Cinematic Teal';
      adjustments = {
        ...adjustments,
        contrast: 22,
        saturation: -5,
        temperature: -10,
        tint: 8,
        highlights: -15,
        shadows: 18,
        vignette: 28,
        grain: 15,
        sharpness: 25,
      };
      explanation = 'Adjusted contrast, muted saturation, balanced teal-orange tone curves, and added cinematic vignette.';
    } else if (lower.includes('warm') || lower.includes('sunset') || lower.includes('golden')) {
      filter = 'Golden Hour';
      adjustments = {
        ...adjustments,
        exposure: 8,
        temperature: 28,
        tint: 12,
        highlights: -10,
        shadows: 14,
        vibrance: 20,
        vignette: 15,
      };
      explanation = 'Shifted color balance towards warm golden amber tones and lifted warm highlights.';
    } else if (lower.includes('bright') || lower.includes('light') || lower.includes('face')) {
      filter = 'Portrait Soft';
      adjustments = {
        ...adjustments,
        exposure: 18,
        brightness: 12,
        contrast: -6,
        shadows: 24,
        whites: 10,
        clarity: 15,
      };
      explanation = 'Lifted midtone exposure and softened deep shadows for glowing, flattering lighting.';
    } else {
      adjustments = {
        ...adjustments,
        exposure: 10,
        contrast: 15,
        vibrance: 15,
        clarity: 20,
        sharpness: 20,
      };
      explanation = 'Enhanced photo dynamics: auto-balanced contrast, boosted natural vibrance, and increased clarity.';
    }

    return res.json({
      adjustments,
      filter,
      explanation,
      mode: 'smart-local-rule-engine-fallback',
      warning: error?.message || 'Remote model fell back to local engine',
    });
  }
});

// AI Background Generator endpoint
app.post('/api/ai/generate-background', async (req, res) => {
  const { prompt, aspectRatio = '1:1' } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Background prompt is required' });
  }

  if (!ai || !hasGeminiKey) {
    return res.status(503).json({
      error: 'Gemini API Key is not configured on the server. Configure GEMINI_API_KEY in the AI Studio Secrets panel to enable direct generative image backgrounds. You can also pick from Pixora\'s built-in luxury studio backdrops and gradients.',
      fallbackAvailable: true,
    });
  }

  try {
    const validRatios = ['1:1', '3:4', '4:3', '9:16', '16:9'];
    const chosenRatio = validRatios.includes(aspectRatio) ? aspectRatio : '1:1';

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-image',
      contents: {
        parts: [
          {
            text: `High quality studio photography background backdrop, cinematic depth of field, ultra realistic, no human subject: ${prompt}`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: chosenRatio as any,
        },
      },
    });

    let imageUrl = '';
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData?.data) {
          imageUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
          break;
        }
      }
    }

    if (!imageUrl) {
      return res.status(502).json({ error: 'No image was returned by the generative model.' });
    }

    return res.json({ imageUrl, prompt });
  } catch (error: any) {
    console.error('Gemini Generate Background Error:', error);
    return res.status(500).json({
      error: error?.message || 'Failed to generate background image',
    });
  }
});

// Complete Android Studio Project ZIP Download Endpoint
app.get('/api/download-android-project', async (_req, res) => {
  try {
    const fs = await import('fs');
    const outZipPath = path.join(__dirname, 'pixora-ai-pro-android-studio-project.zip');
    if (fs.existsSync(outZipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="pixora-ai-pro-android-studio-project.zip"');
      return res.sendFile(outZipPath);
    }

    const JSZip = (await import('jszip')).default;
    const zip = new JSZip();

    // 1. Root Capacitor and Project Config
    zip.file(
      'capacitor.config.json',
      JSON.stringify(
        {
          appId: 'ai.pixora.photoeditor',
          appName: 'PIXORA AI Pro',
          webDir: 'public',
          bundledWebRuntime: false,
          server: {
            androidScheme: 'https',
            cleartext: true,
          },
          android: {
            allowMixedContent: true,
            captureInput: true,
            webContentsDebuggingEnabled: false,
          },
        },
        null,
        2
      )
    );

    zip.file(
      'package.json',
      JSON.stringify(
        {
          name: 'pixora-ai-pro',
          version: '2.4.0',
          private: true,
          description: 'PIXORA AI — Professional AI Photo Editor Pro for Android',
          scripts: {
            'build:apk': './gradlew assembleDebug',
            'build:release': './gradlew assembleRelease',
          },
        },
        null,
        2
      )
    );

    // 2. Comprehensive Android Build & Installation Guide
    zip.file(
      'README_ANDROID_BUILD.md',
      `# PIXORA AI Pro — Android Native Build & Installation Guide

Package Identifier: \`ai.pixora.photoeditor\`
Target SDK: 34 (Android 14)
Min SDK: 24 (Android 7.0+)
Build Type: Debug / Signed Release APK

---

## ⚡ Option 1: Fast Build in Android Studio (Recommended)

1. **Prerequisites**: Install [Android Studio](https://developer.android.com/studio) (Giraffe, Hedgehog, or newer) with Android SDK 34 and JDK 17+.
2. **Open Project**: Launch Android Studio, select **Open**, and choose this extracted project directory.
3. **Sync Gradle**: Allow Gradle to download dependencies automatically.
4. **Build APK**:
   - Go to menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - Or click the green **Run** button to install directly on a connected Android phone or emulator.
5. **Locate APK**:
   The output APK will be saved to:
   \`app/build/outputs/apk/debug/app-debug.apk\`
6. **Install on Phone**:
   - Copy \`app-debug.apk\` to your phone via USB cable, Google Drive, or WhatsApp.
   - Tap the APK file to install (allow "Install unknown apps" if prompted).

---

## 💻 Option 2: Command-Line Terminal Build (Gradle)

\`\`\`bash
# 1. Ensure ANDROID_HOME is set
export ANDROID_HOME=$HOME/Android/Sdk

# 2. Make Gradle wrapper executable
chmod +x gradlew

# 3. Compile the debug APK
./gradlew assembleDebug

# 4. View generated APK
ls -lh app/build/outputs/apk/debug/app-debug.apk

# 5. (Optional) Install directly to connected phone with ADB
adb install -r app/build/outputs/apk/debug/app-debug.apk
\`\`\`

---

## ☁️ Option 3: Automated Free GitHub Actions APK Cloud Build

1. Push this folder to a GitHub repository (public or private).
2. Go to **Actions** tab in GitHub.
3. The included workflow (\`.github/workflows/build-apk.yml\`) will automatically run Gradle on Ubuntu.
4. Download the ready-to-install \`pixora-ai-pro-debug.apk\` from GitHub **Artifacts** in ~2 minutes!
`
    );

    // 3. GitHub Actions Automated CI Workflow
    zip.file(
      '.github/workflows/build-apk.yml',
      `name: Build Android APK
on: [push, workflow_dispatch]

jobs:
  build:
    name: Assemble Android APK
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Build Debug APK
        run: |
          chmod +x gradlew || true
          ./gradlew assembleDebug --stacktrace

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: pixora-ai-pro-debug.apk
          path: app/build/outputs/apk/debug/app-debug.apk
`
    );

    // 4. Root Gradle Scripts
    zip.file(
      'build.gradle',
      `buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.2.2'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
`
    );

    zip.file(
      'settings.gradle',
      `include ':app'
rootProject.name = "PixoraAI"
`
    );

    zip.file(
      'gradlew',
      `#!/bin/sh
exec gradle "$@"
`
    );

    zip.file(
      'gradle/wrapper/gradle-wrapper.properties',
      `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.2-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
    );

    // 5. app/build.gradle
    zip.file(
      'app/build.gradle',
      `plugins {
    id 'com.android.application'
}

android {
    namespace "ai.pixora.photoeditor"
    compileSdk 34

    defaultConfig {
        applicationId "ai.pixora.photoeditor"
        minSdk 24
        targetSdk 34
        versionCode 24
        versionName "2.4.0"
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            shrinkResources false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            applicationIdSuffix ".debug"
            debuggable true
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.activity:activity:1.8.2'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.webkit:webkit:1.9.0'
}
`
    );

    // 6. Android Manifest
    zip.file(
      'app/src/main/AndroidManifest.xml',
      `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />

    <uses-feature android:name="android.hardware.camera" android:required="false" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher"
        android:supportsRtl="true"
        android:hardwareAccelerated="true"
        android:theme="@style/Theme.PixoraAI">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:theme="@style/Theme.PixoraAI.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`
    );

    // 7. Java MainActivity with WebView & Camera/Media File Chooser
    zip.file(
      'app/src/main/java/ai/pixora/photoeditor/MainActivity.java',
      `package ai.pixora.photoeditor;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        
        // Load production offline assets bundled inside app
        webView.loadUrl("file:///android_asset/public/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
`
    );

    // 8. Android Resources
    zip.file(
      'app/src/main/res/values/strings.xml',
      `<resources>
    <string name="app_name">PIXORA AI</string>
</resources>
`
    );

    zip.file(
      'app/src/main/res/values/styles.xml',
      `<resources>
    <style name="Theme.PixoraAI" parent="Theme.Material3.DayNight.NoActionBar">
        <item name="colorPrimary">#8B5CF6</item>
        <item name="colorSecondary">#06B6D4</item>
        <item name="android:statusBarColor">#0B0D14</item>
        <item name="android:navigationBarColor">#0B0D14</item>
    </style>
    <style name="Theme.PixoraAI.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="windowNoTitle">true</item>
    </style>
</resources>
`
    );

    // 9. Embed compiled dist assets into app/src/main/assets/public/
    const distDir = path.join(__dirname, 'dist');
    if (fs.existsSync(distDir)) {
      function addDirToZip(dirPath: string, zipPrefix: string) {
        const files = fs.readdirSync(dirPath);
        for (const file of files) {
          const fullPath = path.join(dirPath, file);
          const stat = fs.statSync(fullPath);
          if (stat.isDirectory()) {
            addDirToZip(fullPath, `${zipPrefix}/${file}`);
          } else {
            zip.file(`${zipPrefix}/${file}`, fs.readFileSync(fullPath));
          }
        }
      }
      addDirToZip(distDir, 'app/src/main/assets/public');
    }

    const zipBuffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="pixora-ai-pro-android-studio-project.zip"');
    res.send(zipBuffer);
  } catch (err: any) {
    console.error('Failed to generate android zip endpoint:', err);
    res.status(500).json({ error: err?.message || 'Failed to generate project ZIP' });
  }
});

// Vite or Static Assets handling
async function setupServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 PIXORA AI Pro Server running at http://0.0.0.0:${PORT}`);
  });
}

setupServer().catch((err) => {
  console.error('Fatal server boot error:', err);
  process.exit(1);
});
