import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ScreenType,
  Language,
  ImageAdjustments,
  GeometryTransform,
  FilterPreset,
  TextLayer,
  StickerLayer,
  ProjectState,
  ExportHistoryItem,
} from './types';
import { useTranslation } from './utils/translations';
import {
  DEFAULT_ADJUSTMENTS,
  DEFAULT_GEOMETRY,
  FILTER_PRESETS,
  loadImage,
  inpaintMaskedArea,
} from './utils/imageProcessing';
import {
  getAllProjects,
  saveProject,
  getAllExports,
  saveAutoSaveState,
  getAutoSaveState,
} from './utils/projectStorage';
import { SplashOnboarding } from './components/SplashOnboarding';
import { HomeDashboard } from './components/HomeDashboard';
import { EditorCanvas } from './components/EditorCanvas';
import { AdjustmentsPanel } from './components/AdjustmentsPanel';
import { FiltersPanel } from './components/FiltersPanel';
import { AiToolsModal } from './components/AiToolsModal';
import { ThreePhotoStudio } from './components/ThreePhotoStudio';
import { CollageMaker } from './components/CollageMaker';
import { TextStickerEditor } from './components/TextStickerEditor';
import { ExportModal } from './components/ExportModal';
import { BuildDownloadScreen } from './components/BuildDownloadScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { ExportsListScreen } from './components/ExportsListScreen';
import { ProjectsListScreen } from './components/ProjectsListScreen';
import { CameraCaptureModal } from './components/CameraCaptureModal';

import {
  ArrowLeft,
  RotateCcw,
  RotateCw,
  Sliders,
  Palette,
  Wand2,
  Crop,
  Type,
  Rotate3d,
  Download,
  Save,
  Smartphone,
  Maximize2,
  Minimize2,
  Sparkles,
  Scissors,
  Check,
} from 'lucide-react';

export default function App() {
  const [screen, setScreen] = useState<ScreenType>('home');
  const [lang, setLang] = useState<Language>('en');
  const [isMobileFrame, setIsMobileFrame] = useState(false);

  // Editor State
  const [originalImage, setOriginalImage] = useState<HTMLImageElement | null>(null);
  const [originalDataUrl, setOriginalDataUrl] = useState<string>('');
  const [projectId, setProjectId] = useState<string>('');
  const [projectName, setProjectName] = useState<string>('My Edit');
  const [adjustments, setAdjustments] = useState<ImageAdjustments>(DEFAULT_ADJUSTMENTS);
  const [geometry, setGeometry] = useState<GeometryTransform>(DEFAULT_GEOMETRY);
  const [activeFilterId, setActiveFilterId] = useState<string>('original');
  const [filterIntensity, setFilterIntensity] = useState<number>(100);
  const [textLayers, setTextLayers] = useState<TextLayer[]>([]);
  const [stickerLayers, setStickerLayers] = useState<StickerLayer[]>([]);
  const [maskCanvas, setMaskCanvas] = useState<HTMLCanvasElement | null>(null);
  const [backgroundStyle, setBackgroundStyle] = useState<{
    type: 'none' | 'color' | 'gradient' | 'image';
    value?: string;
  }>({ type: 'none' });

  // Undo / Redo History Stack
  interface HistoryStep {
    adjustments: ImageAdjustments;
    geometry: GeometryTransform;
    activeFilterId: string;
    filterIntensity: number;
    textLayers: TextLayer[];
    stickerLayers: StickerLayer[];
  }
  const [history, setHistory] = useState<HistoryStep[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);

  // Active Tool Panel in Editor
  const [activeTool, setActiveTool] = useState<'adjust' | 'filters' | 'none'>('adjust');

  // Modals
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [initialAiTool, setInitialAiTool] = useState('assistant');
  const [isTextModalOpen, setIsTextModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);

  // Eraser brush mode
  const [isEraserMode, setIsEraserMode] = useState(false);

  // Rendered canvas reference for export / 3D studio
  const renderedCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Recent data
  const [recentProjects, setRecentProjects] = useState<ProjectState[]>([]);
  const [recentExports, setRecentExports] = useState<ExportHistoryItem[]>([]);

  const t = useTranslation(lang);

  // Load storage on mount
  useEffect(() => {
    setRecentProjects(getAllProjects());
    setRecentExports(getAllExports());
  }, []);

  // Push history step
  const pushHistory = useCallback(
    (newAdj: ImageAdjustments, newGeo: GeometryTransform, newFilterId: string, newIntensity: number) => {
      const step: HistoryStep = {
        adjustments: newAdj,
        geometry: newGeo,
        activeFilterId: newFilterId,
        filterIntensity: newIntensity,
        textLayers,
        stickerLayers,
      };

      setHistory((prev) => [...prev.slice(0, historyIndex + 1), step]);
      setHistoryIndex((prev) => prev + 1);
    },
    [historyIndex, textLayers, stickerLayers]
  );

  // Undo action
  const handleUndo = () => {
    if (historyIndex > 0) {
      const targetIndex = historyIndex - 1;
      const step = history[targetIndex];
      setAdjustments(step.adjustments);
      setGeometry(step.geometry);
      setActiveFilterId(step.activeFilterId);
      setFilterIntensity(step.filterIntensity);
      setTextLayers(step.textLayers);
      setStickerLayers(step.stickerLayers);
      setHistoryIndex(targetIndex);
    }
  };

  // Redo action
  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const targetIndex = historyIndex + 1;
      const step = history[targetIndex];
      setAdjustments(step.adjustments);
      setGeometry(step.geometry);
      setActiveFilterId(step.activeFilterId);
      setFilterIntensity(step.filterIntensity);
      setTextLayers(step.textLayers);
      setStickerLayers(step.stickerLayers);
      setHistoryIndex(targetIndex);
    }
  };

  // Start new edit from image URL / file
  const handleStartPhotoEdit = async (dataUrl: string, autoTool?: string) => {
    try {
      const img = await loadImage(dataUrl);
      setOriginalImage(img);
      setOriginalDataUrl(dataUrl);
      setProjectId('proj-' + Date.now());
      setProjectName('Pixora Photo ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));

      // Reset parameters
      setAdjustments(DEFAULT_ADJUSTMENTS);
      setGeometry(DEFAULT_GEOMETRY);
      setActiveFilterId('original');
      setFilterIntensity(100);
      setTextLayers([]);
      setStickerLayers([]);
      setMaskCanvas(null);
      setBackgroundStyle({ type: 'none' });
      setIsEraserMode(false);

      // Initialize history
      const initialStep: HistoryStep = {
        adjustments: DEFAULT_ADJUSTMENTS,
        geometry: DEFAULT_GEOMETRY,
        activeFilterId: 'original',
        filterIntensity: 100,
        textLayers: [],
        stickerLayers: [],
      };
      setHistory([initialStep]);
      setHistoryIndex(0);

      setScreen('editor');

      // Auto-open specific tool if requested
      if (autoTool) {
        if (autoTool === 'ai-assistant') {
          setInitialAiTool('assistant');
          setIsAiModalOpen(true);
        } else if (autoTool === 'remove-bg') {
          setInitialAiTool('remove-bg');
          setIsAiModalOpen(true);
        } else if (autoTool === 'ai-eraser') {
          setIsEraserMode(true);
        } else if (autoTool === 'enhance') {
          setInitialAiTool('enhance');
          setIsAiModalOpen(true);
        } else if (autoTool === 'portrait') {
          setInitialAiTool('portrait');
          setIsAiModalOpen(true);
        } else if (autoTool === 'filters') {
          setActiveTool('filters');
        } else if (autoTool === 'style-transfer') {
          setInitialAiTool('style');
          setIsAiModalOpen(true);
        } else if (autoTool === 'text') {
          setIsTextModalOpen(true);
        }
      }
    } catch (err) {
      console.error('Failed to open image:', err);
    }
  };

  // Open existing project
  const handleOpenRecentProject = async (p: ProjectState) => {
    try {
      const img = await loadImage(p.originalImage);
      setOriginalImage(img);
      setOriginalDataUrl(p.originalImage);
      setProjectId(p.id);
      setProjectName(p.name);
      setAdjustments(p.currentAdjustments);
      setGeometry(p.geometry);
      setActiveFilterId(p.activeFilter);
      setFilterIntensity(p.filterIntensity);
      setTextLayers(p.textLayers);
      setStickerLayers(p.stickerLayers);

      // Re-init history
      const step: HistoryStep = {
        adjustments: p.currentAdjustments,
        geometry: p.geometry,
        activeFilterId: p.activeFilter,
        filterIntensity: p.filterIntensity,
        textLayers: p.textLayers,
        stickerLayers: p.stickerLayers,
      };
      setHistory([step]);
      setHistoryIndex(0);

      setScreen('editor');
    } catch (err) {
      console.error('Could not reopen project:', err);
    }
  };

  // Save current project state to LocalStorage
  const handleSaveCurrentProject = () => {
    if (!originalDataUrl || !renderedCanvasRef.current) return;
    const thumbnail = renderedCanvasRef.current.toDataURL('image/jpeg', 0.6);

    const project: ProjectState = {
      id: projectId || 'proj-' + Date.now(),
      name: projectName,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      thumbnailUrl: thumbnail,
      originalImage: originalDataUrl,
      currentAdjustments: adjustments,
      geometry,
      activeFilter: activeFilterId,
      filterIntensity,
      textLayers,
      stickerLayers,
      width: originalImage?.naturalWidth || 1200,
      height: originalImage?.naturalHeight || 800,
    };

    saveProject(project);
    setRecentProjects(getAllProjects());
    alert('Project saved successfully to local storage!');
  };

  // Eraser mask drawn
  const handleEraserDraw = (eraserMaskCanvas: HTMLCanvasElement) => {
    if (renderedCanvasRef.current) {
      inpaintMaskedArea(renderedCanvasRef.current, eraserMaskCanvas);
    }
  };

  const activeFilterPreset = FILTER_PRESETS.find((p) => p.id === activeFilterId);

  return (
    <div className="min-h-screen bg-[#07090f] text-slate-100 flex flex-col items-center justify-center">
      {/* Wrapper to support mobile device frame testing */}
      <div
        className={`w-full transition-all duration-300 flex flex-col ${
          isMobileFrame
            ? 'max-w-[420px] h-[92vh] max-h-[880px] my-auto rounded-[42px] border-[8px] border-[#1f2438] shadow-[0_0_50px_rgba(0,0,0,0.8)] overflow-hidden relative'
            : 'min-h-screen'
        }`}
      >
        {/* Device Status Bar if in mobile frame mode */}
        {isMobileFrame && (
          <div className="bg-[#0b0d14] px-6 py-2 flex items-center justify-between text-[11px] font-mono text-slate-400 select-none z-40">
            <span>9:41</span>
            <div className="w-16 h-3.5 bg-slate-900 rounded-full mx-auto" />
            <div className="flex items-center gap-1.5">
              <span>5G</span>
              <div className="w-4 h-2 rounded-sm border border-slate-400 p-[1px]">
                <div className="w-full h-full bg-emerald-400" />
              </div>
            </div>
          </div>
        )}

        {/* Global Floating Frame Toggle (Desktop / Mobile Preview) */}
        <div className="fixed bottom-3 right-3 z-50 flex items-center gap-2">
          <button
            onClick={() => setIsMobileFrame(!isMobileFrame)}
            className="flex items-center gap-1.5 bg-[#121624]/90 hover:bg-purple-600/30 border border-slate-800 hover:border-purple-500/50 text-slate-300 text-xs font-semibold px-3 py-1.5 rounded-full shadow-2xl backdrop-blur transition-all"
            title="Toggle Smartphone Frame View"
          >
            {isMobileFrame ? (
              <>
                <Maximize2 className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">Full Width</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-purple-400" />
                <span className="hidden sm:inline">Phone Frame</span>
              </>
            )}
          </button>
        </div>

        {/* SCREEN 1: SPLASH & ONBOARDING */}
        {screen === 'onboarding' && (
          <SplashOnboarding
            onComplete={() => setScreen('home')}
            lang={lang}
          />
        )}

        {/* SCREEN 2: HOME DASHBOARD */}
        {screen === 'home' && (
          <HomeDashboard
            onSelectPhoto={handleStartPhotoEdit}
            onOpenRecentProject={handleOpenRecentProject}
            onOpenExports={() => setScreen('exports')}
            onOpenProjects={() => setScreen('projects')}
            onOpenCollage={() => setScreen('collage')}
            onOpenBuildApk={() => setScreen('build-apk')}
            onOpenSettings={() => setScreen('settings')}
            onOpenCamera={() => setIsCameraOpen(true)}
            recentProjects={recentProjects}
            recentExports={recentExports}
            lang={lang}
            onToggleLang={() => setLang((l) => (l === 'en' ? 'hi' : 'en'))}
          />
        )}

        {/* SCREEN 3: MAIN PHOTO EDITOR */}
        {screen === 'editor' && (
          <div className="flex-1 flex flex-col justify-between h-full bg-[#0b0d14] relative select-none">
            {/* Top Editor Bar */}
            <div className="bg-[#0e121e]/95 backdrop-blur border-b border-slate-800 px-3 py-2 flex items-center justify-between z-30">
              <button
                onClick={() => setScreen('home')}
                className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white"
                title="Back to Home"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>

              {/* Center Controls: Undo / Redo */}
              <div className="flex items-center gap-1.5 bg-slate-950/80 border border-slate-800 px-2 py-1 rounded-full">
                <button
                  onClick={handleUndo}
                  disabled={historyIndex <= 0}
                  className="w-7 h-7 rounded-full flex items-center justify-center text-slate-300 hover:text-white disabled:opacity-30 disabled:hover:text-slate-300"
                  title="Undo"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <span className="text-[10px] font-mono text-slate-500">
                  {historyIndex + 1}/{history.length}
                </span>
                <button
                  onClick={handleRedo}
                  disabled={historyIndex >= history.length - 1}
                  className="w-7 h-7 rounded-full flex items-center justify-center text-slate-300 hover:text-white disabled:opacity-30 disabled:hover:text-slate-300"
                  title="Redo"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Action Buttons: 3D Studio, Save Project, Export */}
              <div className="flex items-center gap-1.5">
                {/* 3D Studio button */}
                <button
                  onClick={() => setScreen('three-studio')}
                  className="flex items-center gap-1 bg-purple-600/20 border border-purple-500/40 text-purple-300 px-2.5 py-1.5 rounded-xl text-xs font-semibold hover:bg-purple-600 hover:text-white transition-colors"
                  title="View in Three.js 3D Studio Stage"
                >
                  <Rotate3d className="w-3.5 h-3.5 text-purple-400" />
                  <span className="hidden sm:inline">3D</span>
                </button>

                {/* Save Project */}
                <button
                  onClick={handleSaveCurrentProject}
                  className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex items-center justify-center text-slate-300"
                  title="Save Project"
                >
                  <Save className="w-4 h-4" />
                </button>

                {/* Export Button */}
                <button
                  onClick={() => setIsExportModalOpen(true)}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-semibold text-xs shadow-md transition-all active:scale-95"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{t.export}</span>
                </button>
              </div>
            </div>

            {/* Main Interactive Canvas Area */}
            <div className="flex-1 relative overflow-hidden">
              <EditorCanvas
                originalImage={originalImage}
                adjustments={adjustments}
                geometry={geometry}
                activeFilter={activeFilterPreset}
                filterIntensity={filterIntensity}
                textLayers={textLayers}
                stickerLayers={stickerLayers}
                maskCanvas={maskCanvas}
                backgroundStyle={backgroundStyle}
                isEraserMode={isEraserMode}
                onEraserDraw={handleEraserDraw}
                onCanvasReady={(cvs) => {
                  renderedCanvasRef.current = cvs;
                }}
              />
            </div>

            {/* Bottom Docked Panel Area (Adjustments / Filters) */}
            <div className="z-20">
              {activeTool === 'adjust' && (
                <AdjustmentsPanel
                  adjustments={adjustments}
                  geometry={geometry}
                  onChangeAdjustments={(newAdj) => {
                    setAdjustments(newAdj);
                    pushHistory(newAdj, geometry, activeFilterId, filterIntensity);
                  }}
                  onChangeGeometry={(newGeo) => {
                    setGeometry(newGeo);
                    pushHistory(adjustments, newGeo, activeFilterId, filterIntensity);
                  }}
                  onResetAdjustments={() => {
                    setAdjustments(DEFAULT_ADJUSTMENTS);
                    pushHistory(DEFAULT_ADJUSTMENTS, geometry, activeFilterId, filterIntensity);
                  }}
                  lang={lang}
                />
              )}

              {activeTool === 'filters' && (
                <FiltersPanel
                  activeFilterId={activeFilterId}
                  filterIntensity={filterIntensity}
                  onSelectFilter={(preset) => {
                    setActiveFilterId(preset.id);
                    pushHistory(adjustments, geometry, preset.id, filterIntensity);
                  }}
                  onChangeIntensity={(intensity) => {
                    setFilterIntensity(intensity);
                    pushHistory(adjustments, geometry, activeFilterId, intensity);
                  }}
                  lang={lang}
                />
              )}

              {/* Bottom Quick-Switch Toolbar */}
              <div className="bg-[#0b0d14] border-t border-slate-800/80 px-2 py-2 flex items-center justify-around">
                <button
                  onClick={() => setActiveTool('adjust')}
                  className={`flex flex-col items-center gap-1 text-[11px] font-semibold transition-colors ${
                    activeTool === 'adjust' ? 'text-purple-400' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Sliders className="w-5 h-5" />
                  <span>{t.adjust}</span>
                </button>

                <button
                  onClick={() => setActiveTool('filters')}
                  className={`flex flex-col items-center gap-1 text-[11px] font-semibold transition-colors ${
                    activeTool === 'filters' ? 'text-purple-400' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Palette className="w-5 h-5" />
                  <span>{t.filters}</span>
                </button>

                {/* AI Tools Modal trigger */}
                <button
                  onClick={() => {
                    setInitialAiTool('assistant');
                    setIsAiModalOpen(true);
                  }}
                  className="flex flex-col items-center gap-1 text-[11px] font-semibold text-purple-400 hover:text-purple-300 transition-colors"
                >
                  <div className="w-7 h-7 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center">
                    <Wand2 className="w-4 h-4 text-purple-300" />
                  </div>
                  <span>{t.aiTools}</span>
                </button>

                {/* Text & Stickers trigger */}
                <button
                  onClick={() => setIsTextModalOpen(true)}
                  className="flex flex-col items-center gap-1 text-[11px] font-semibold text-slate-400 hover:text-slate-200 transition-colors"
                >
                  <Type className="w-5 h-5" />
                  <span>{t.text}</span>
                </button>

                {/* Eraser Mode Toggle */}
                <button
                  onClick={() => setIsEraserMode(!isEraserMode)}
                  className={`flex flex-col items-center gap-1 text-[11px] font-semibold transition-colors ${
                    isEraserMode ? 'text-rose-400' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Scissors className="w-5 h-5" />
                  <span>{isEraserMode ? 'Exit Eraser' : t.aiEraser}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SCREEN 4: THREE.JS 3D PHOTO STUDIO */}
        {screen === 'three-studio' && (
          <ThreePhotoStudio
            photoCanvas={renderedCanvasRef.current}
            onClose={() => setScreen('editor')}
          />
        )}

        {/* SCREEN 5: COLLAGE MAKER */}
        {screen === 'collage' && (
          <CollageMaker
            onBack={() => setScreen('home')}
            onOpenInEditor={(dataUrl) => handleStartPhotoEdit(dataUrl)}
            lang={lang}
          />
        )}

        {/* SCREEN 6: BUILD & APK DOWNLOAD */}
        {screen === 'build-apk' && (
          <BuildDownloadScreen
            onBack={() => setScreen('home')}
            lang={lang}
          />
        )}

        {/* SCREEN 7: MY EXPORTS */}
        {screen === 'exports' && (
          <ExportsListScreen
            onBack={() => setScreen('home')}
            lang={lang}
          />
        )}

        {/* SCREEN 8: RECENT PROJECTS */}
        {screen === 'projects' && (
          <ProjectsListScreen
            onBack={() => setScreen('home')}
            onOpenProject={handleOpenRecentProject}
            lang={lang}
          />
        )}

        {/* SCREEN 9: SETTINGS & PRIVACY */}
        {screen === 'settings' && (
          <SettingsScreen
            onBack={() => setScreen('home')}
            lang={lang}
            onToggleLang={() => setLang((l) => (l === 'en' ? 'hi' : 'en'))}
          />
        )}

        {/* MODAL: AI TOOLS SUITE */}
        <AiToolsModal
          isOpen={isAiModalOpen}
          onClose={() => setIsAiModalOpen(false)}
          currentAdjustments={adjustments}
          currentCanvas={renderedCanvasRef.current}
          onApplyAdjustments={(newAdj, filterName) => {
            setAdjustments(newAdj);
            if (filterName) setActiveFilterId(filterName);
            pushHistory(newAdj, geometry, filterName || activeFilterId, filterIntensity);
          }}
          onSetMaskCanvas={(mask) => setMaskCanvas(mask)}
          onSetBackgroundStyle={(style) => setBackgroundStyle(style)}
          onStartEraserMode={() => setIsEraserMode(true)}
          lang={lang}
          initialTool={initialAiTool}
        />

        {/* MODAL: TEXT & STICKER EDITOR */}
        <TextStickerEditor
          isOpen={isTextModalOpen}
          onClose={() => setIsTextModalOpen(false)}
          textLayers={textLayers}
          stickerLayers={stickerLayers}
          onAddTextLayer={(layer) => setTextLayers((prev) => [...prev, layer])}
          onUpdateTextLayer={(layer) =>
            setTextLayers((prev) => prev.map((l) => (l.id === layer.id ? layer : l)))
          }
          onDeleteTextLayer={(id) => setTextLayers((prev) => prev.filter((l) => l.id !== id))}
          onAddStickerLayer={(sticker) => setStickerLayers((prev) => [...prev, sticker])}
          onDeleteStickerLayer={(id) => setStickerLayers((prev) => prev.filter((s) => s.id !== id))}
        />

        {/* MODAL: EXPORT & SAVE */}
        <ExportModal
          isOpen={isExportModalOpen}
          onClose={() => setIsExportModalOpen(false)}
          renderedCanvas={renderedCanvasRef.current}
          lang={lang}
        />

        {/* MODAL: CAMERA CAPTURE */}
        <CameraCaptureModal
          isOpen={isCameraOpen}
          onClose={() => setIsCameraOpen(false)}
          onCapture={(dataUrl) => handleStartPhotoEdit(dataUrl)}
        />
      </div>
    </div>
  );
}
