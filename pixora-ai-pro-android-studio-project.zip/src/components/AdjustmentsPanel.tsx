import React, { useState } from 'react';
import {
  ImageAdjustments,
  GeometryTransform,
  Language,
} from '../types';
import { useTranslation } from '../utils/translations';
import {
  Sun,
  Palette,
  Sparkles,
  Film,
  Crop,
  RotateCw,
  FlipHorizontal,
  FlipVertical,
  RotateCcw,
} from 'lucide-react';

interface AdjustmentsPanelProps {
  adjustments: ImageAdjustments;
  geometry: GeometryTransform;
  onChangeAdjustments: (adjustments: ImageAdjustments) => void;
  onChangeGeometry: (geometry: GeometryTransform) => void;
  onResetAdjustments: () => void;
  lang: Language;
}

export const AdjustmentsPanel: React.FC<AdjustmentsPanelProps> = ({
  adjustments,
  geometry,
  onChangeAdjustments,
  onChangeGeometry,
  onResetAdjustments,
  lang,
}) => {
  const t = useTranslation(lang);
  const [activeTab, setActiveTab] = useState<'light' | 'color' | 'detail' | 'effects' | 'crop'>('light');

  const updateParam = (key: keyof ImageAdjustments, value: number) => {
    onChangeAdjustments({
      ...adjustments,
      [key]: value,
    });
  };

  const tabs = [
    { id: 'light', label: t.groupLight, icon: <Sun className="w-4 h-4 text-amber-400" /> },
    { id: 'color', label: t.groupColor, icon: <Palette className="w-4 h-4 text-purple-400" /> },
    { id: 'detail', label: t.groupDetail, icon: <Sparkles className="w-4 h-4 text-cyan-400" /> },
    { id: 'effects', label: t.groupEffects, icon: <Film className="w-4 h-4 text-pink-400" /> },
    { id: 'crop', label: t.groupGeometry, icon: <Crop className="w-4 h-4 text-emerald-400" /> },
  ] as const;

  const aspectRatios = [
    { id: 'original', label: 'Original', ratio: 0 },
    { id: '1:1', label: '1:1 (Square)', ratio: 1 },
    { id: '4:5', label: '4:5 (Insta)', ratio: 4 / 5 },
    { id: '3:4', label: '3:4 (Portrait)', ratio: 3 / 4 },
    { id: '9:16', label: '9:16 (Story)', ratio: 9 / 16 },
    { id: '16:9', label: '16:9 (Landscape)', ratio: 16 / 9 },
  ];

  return (
    <div className="bg-[#0e121e] border-t border-slate-800 flex flex-col max-h-[38vh] select-none">
      {/* Category Tabs Header */}
      <div className="flex items-center justify-between border-b border-slate-800/80 px-2 py-1.5 overflow-x-auto">
        <div className="flex items-center gap-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-purple-600/30 text-purple-300 border border-purple-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Reset Edits button */}
        <button
          onClick={onResetAdjustments}
          className="text-[11px] font-semibold text-slate-400 hover:text-rose-400 flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-800 hover:border-rose-900 transition-colors ml-2 flex-shrink-0"
          title="Reset all adjustments to zero"
        >
          <RotateCcw className="w-3 h-3" />
          <span>{t.reset}</span>
        </button>
      </div>

      {/* Sliders Content Area */}
      <div className="p-4 overflow-y-auto space-y-4">
        {/* LIGHT TAB */}
        {activeTab === 'light' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
            <SliderRow
              label={t.exposure}
              min={-50}
              max={50}
              value={adjustments.exposure}
              onChange={(v) => updateParam('exposure', v)}
              onReset={() => updateParam('exposure', 0)}
            />
            <SliderRow
              label={t.brightness}
              min={-100}
              max={100}
              value={adjustments.brightness}
              onChange={(v) => updateParam('brightness', v)}
              onReset={() => updateParam('brightness', 0)}
            />
            <SliderRow
              label={t.contrast}
              min={-100}
              max={100}
              value={adjustments.contrast}
              onChange={(v) => updateParam('contrast', v)}
              onReset={() => updateParam('contrast', 0)}
            />
            <SliderRow
              label={t.highlights}
              min={-100}
              max={100}
              value={adjustments.highlights}
              onChange={(v) => updateParam('highlights', v)}
              onReset={() => updateParam('highlights', 0)}
            />
            <SliderRow
              label={t.shadows}
              min={-100}
              max={100}
              value={adjustments.shadows}
              onChange={(v) => updateParam('shadows', v)}
              onReset={() => updateParam('shadows', 0)}
            />
            <SliderRow
              label={t.whites}
              min={-100}
              max={100}
              value={adjustments.whites}
              onChange={(v) => updateParam('whites', v)}
              onReset={() => updateParam('whites', 0)}
            />
            <SliderRow
              label={t.blacks}
              min={-100}
              max={100}
              value={adjustments.blacks}
              onChange={(v) => updateParam('blacks', v)}
              onReset={() => updateParam('blacks', 0)}
            />
            <SliderRow
              label={t.gamma}
              min={-50}
              max={50}
              value={adjustments.gamma}
              onChange={(v) => updateParam('gamma', v)}
              onReset={() => updateParam('gamma', 0)}
            />
          </div>
        )}

        {/* COLOR TAB */}
        {activeTab === 'color' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
            <SliderRow
              label={t.temperature}
              min={-100}
              max={100}
              value={adjustments.temperature}
              onChange={(v) => updateParam('temperature', v)}
              onReset={() => updateParam('temperature', 0)}
            />
            <SliderRow
              label={t.tint}
              min={-100}
              max={100}
              value={adjustments.tint}
              onChange={(v) => updateParam('tint', v)}
              onReset={() => updateParam('tint', 0)}
            />
            <SliderRow
              label={t.saturation}
              min={-100}
              max={100}
              value={adjustments.saturation}
              onChange={(v) => updateParam('saturation', v)}
              onReset={() => updateParam('saturation', 0)}
            />
            <SliderRow
              label={t.vibrance}
              min={-100}
              max={100}
              value={adjustments.vibrance}
              onChange={(v) => updateParam('vibrance', v)}
              onReset={() => updateParam('vibrance', 0)}
            />
            <SliderRow
              label={t.hue}
              min={-180}
              max={180}
              value={adjustments.hue}
              onChange={(v) => updateParam('hue', v)}
              onReset={() => updateParam('hue', 0)}
            />
          </div>
        )}

        {/* DETAIL TAB */}
        {activeTab === 'detail' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
            <SliderRow
              label={t.sharpness}
              min={0}
              max={100}
              value={adjustments.sharpness}
              onChange={(v) => updateParam('sharpness', v)}
              onReset={() => updateParam('sharpness', 0)}
            />
            <SliderRow
              label={t.clarity}
              min={-50}
              max={50}
              value={adjustments.clarity}
              onChange={(v) => updateParam('clarity', v)}
              onReset={() => updateParam('clarity', 0)}
            />
            <SliderRow
              label={t.blur}
              min={0}
              max={50}
              value={adjustments.blur}
              onChange={(v) => updateParam('blur', v)}
              onReset={() => updateParam('blur', 0)}
            />
          </div>
        )}

        {/* EFFECTS TAB */}
        {activeTab === 'effects' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
            <SliderRow
              label={t.vignette}
              min={0}
              max={100}
              value={adjustments.vignette}
              onChange={(v) => updateParam('vignette', v)}
              onReset={() => updateParam('vignette', 0)}
            />
            <SliderRow
              label={t.grain}
              min={0}
              max={100}
              value={adjustments.grain}
              onChange={(v) => updateParam('grain', v)}
              onReset={() => updateParam('grain', 0)}
            />
            <SliderRow
              label={t.fade}
              min={0}
              max={100}
              value={adjustments.fade}
              onChange={(v) => updateParam('fade', v)}
              onReset={() => updateParam('fade', 0)}
            />
          </div>
        )}

        {/* CROP & GEOMETRY TAB */}
        {activeTab === 'crop' && (
          <div className="space-y-4">
            {/* Aspect Ratio Buttons */}
            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
                Aspect Ratio Presets
              </span>
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {aspectRatios.map((ar) => (
                  <button
                    key={ar.id}
                    onClick={() => {
                      onChangeGeometry({
                        ...geometry,
                        aspectRatio: ar.id,
                      });
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                      geometry.aspectRatio === ar.id
                        ? 'bg-purple-600 text-white border-purple-400 shadow-sm'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {ar.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Straighten Rotation Slider */}
            <SliderRow
              label={t.straighten}
              min={-45}
              max={45}
              value={geometry.rotation}
              onChange={(v) => onChangeGeometry({ ...geometry, rotation: v })}
              onReset={() => onChangeGeometry({ ...geometry, rotation: 0 })}
            />

            {/* Rotate & Flip Quick Actions */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() =>
                  onChangeGeometry({
                    ...geometry,
                    rotation: (geometry.rotation + 90) % 360,
                  })
                }
                className="flex-1 py-2 px-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex items-center justify-center gap-2 text-xs font-semibold text-slate-300"
              >
                <RotateCw className="w-3.5 h-3.5 text-cyan-400" />
                <span>Rotate 90°</span>
              </button>
              <button
                onClick={() =>
                  onChangeGeometry({
                    ...geometry,
                    flipH: !geometry.flipH,
                  })
                }
                className={`flex-1 py-2 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold transition-colors ${
                  geometry.flipH
                    ? 'bg-purple-600/30 text-purple-300 border-purple-500/50'
                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                }`}
              >
                <FlipHorizontal className="w-3.5 h-3.5 text-purple-400" />
                <span>Flip H</span>
              </button>
              <button
                onClick={() =>
                  onChangeGeometry({
                    ...geometry,
                    flipV: !geometry.flipV,
                  })
                }
                className={`flex-1 py-2 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold transition-colors ${
                  geometry.flipV
                    ? 'bg-purple-600/30 text-purple-300 border-purple-500/50'
                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                }`}
              >
                <FlipVertical className="w-3.5 h-3.5 text-pink-400" />
                <span>Flip V</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Reusable slider row with double-click reset and numeric indicator
interface SliderRowProps {
  label: string;
  min: number;
  max: number;
  value: number;
  onChange: (value: number) => void;
  onReset: () => void;
}

const SliderRow: React.FC<SliderRowProps> = ({
  label,
  min,
  max,
  value,
  onChange,
  onReset,
}) => {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span
          onDoubleClick={onReset}
          className="text-slate-300 font-medium cursor-pointer hover:text-white"
          title="Double click to reset"
        >
          {label}
        </span>
        <button
          onClick={onReset}
          className={`font-mono text-[11px] px-1.5 py-0.5 rounded transition-colors ${
            value !== 0
              ? 'bg-purple-500/20 text-purple-300 font-semibold'
              : 'text-slate-500'
          }`}
          title="Reset parameter"
        >
          {value > 0 ? `+${value}` : value}
        </button>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full"
      />
    </div>
  );
};
