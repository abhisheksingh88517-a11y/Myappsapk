import React, { useState } from 'react';
import {
  Wand2,
  Scissors,
  Eraser,
  Flame,
  UserCheck,
  Paintbrush,
  Sparkles,
  Send,
  Loader2,
  Check,
  X,
  AlertCircle,
  Palette,
} from 'lucide-react';
import { Language, ImageAdjustments } from '../types';
import { useTranslation } from '../utils/translations';
import {
  segmentForeground,
  applyPortraitRetouch,
  inpaintMaskedArea,
} from '../utils/imageProcessing';

interface AiToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAdjustments: ImageAdjustments;
  currentCanvas: HTMLCanvasElement | null;
  onApplyAdjustments: (adjustments: ImageAdjustments, filterName?: string) => void;
  onSetMaskCanvas: (maskCanvas: HTMLCanvasElement | null) => void;
  onSetBackgroundStyle: (style: {
    type: 'none' | 'color' | 'gradient' | 'image';
    value?: string;
  }) => void;
  onStartEraserMode: () => void;
  lang: Language;
  initialTool?: string;
}

export const AiToolsModal: React.FC<AiToolsModalProps> = ({
  isOpen,
  onClose,
  currentAdjustments,
  currentCanvas,
  onApplyAdjustments,
  onSetMaskCanvas,
  onSetBackgroundStyle,
  onStartEraserMode,
  lang,
  initialTool = 'assistant',
}) => {
  const t = useTranslation(lang);
  const [activeTab, setActiveTab] = useState<string>(initialTool);

  // AI Assistant state
  const [assistantPrompt, setAssistantPrompt] = useState('');
  const [isAssistantLoading, setIsAssistantLoading] = useState(false);
  const [assistantExplanation, setAssistantExplanation] = useState<string | null>(null);

  // Background Remover state
  const [bgSensitivity, setBgSensitivity] = useState(50);
  const [bgType, setBgType] = useState<'transparent' | 'solid' | 'gradient' | 'ai'>('transparent');
  const [solidColor, setSolidColor] = useState('#1e293b');
  const [gradientType, setGradientType] = useState('sunset');
  const [aiBgPrompt, setAiBgPrompt] = useState('luxury minimalist marble architectural studio');
  const [isAiBgLoading, setIsAiBgLoading] = useState(false);
  const [aiBgError, setAiBgError] = useState<string | null>(null);

  // Portrait Retouch state
  const [skinSmoothIntensity, setSkinSmoothIntensity] = useState(65);

  // Style Transfer state
  const [selectedStyle, setSelectedStyle] = useState<string>('cinematic');

  if (!isOpen) return null;

  // Handle AI Assistant submit
  const handleAssistantSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!assistantPrompt.trim() || isAssistantLoading) return;

    setIsAssistantLoading(true);
    setAssistantExplanation(null);

    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: assistantPrompt,
          currentAdjustments,
        }),
      });

      const data = await res.json();
      if (data.adjustments) {
        onApplyAdjustments(data.adjustments, data.filter);
        setAssistantExplanation(data.explanation || 'Adjustments applied successfully.');
      }
    } catch (err: any) {
      setAssistantExplanation('Error: ' + (err?.message || 'Could not connect to AI service'));
    } finally {
      setIsAssistantLoading(false);
    }
  };

  // Handle AI Background Removal
  const handleApplyBackgroundRemoval = () => {
    if (!currentCanvas) return;
    const mask = segmentForeground(currentCanvas, bgSensitivity / 100);
    onSetMaskCanvas(mask);

    if (bgType === 'transparent') {
      onSetBackgroundStyle({ type: 'none' });
    } else if (bgType === 'solid') {
      onSetBackgroundStyle({ type: 'color', value: solidColor });
    } else if (bgType === 'gradient') {
      onSetBackgroundStyle({ type: 'gradient', value: gradientType });
    }
    onClose();
  };

  // Handle AI Background Generation via Gemini
  const handleGenerateAiBackground = async () => {
    if (!aiBgPrompt.trim() || isAiBgLoading) return;
    setIsAiBgLoading(true);
    setAiBgError(null);

    try {
      const res = await fetch('/api/ai/generate-background', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: aiBgPrompt, aspectRatio: '1:1' }),
      });

      const data = await res.json();
      if (res.ok && data.imageUrl) {
        onSetBackgroundStyle({ type: 'image', value: data.imageUrl });
        onClose();
      } else {
        setAiBgError(
          data.error ||
            'Gemini image generation requires an active paid API key configured in AI Studio Secrets.'
        );
      }
    } catch (err: any) {
      setAiBgError('Network or server error: ' + (err?.message || 'Failed'));
    } finally {
      setIsAiBgLoading(false);
    }
  };

  // Handle AI Photo Enhancer (Instant unsharp & contrast dynamic expansion)
  const handleEnhancePhoto = () => {
    onApplyAdjustments(
      {
        ...currentAdjustments,
        contrast: Math.min(100, currentAdjustments.contrast + 18),
        highlights: Math.min(100, currentAdjustments.highlights - 10),
        shadows: Math.min(100, currentAdjustments.shadows + 18),
        whites: Math.min(100, currentAdjustments.whites + 10),
        sharpness: Math.min(100, currentAdjustments.sharpness + 35),
        clarity: Math.min(50, currentAdjustments.clarity + 22),
        vibrance: Math.min(100, currentAdjustments.vibrance + 15),
      },
      'AI Enhanced'
    );
    onClose();
  };

  // Handle Portrait Retouch apply
  const handlePortraitRetouch = () => {
    if (currentCanvas) {
      applyPortraitRetouch(currentCanvas, skinSmoothIntensity);
    }
    onApplyAdjustments(
      {
        ...currentAdjustments,
        exposure: Math.min(50, currentAdjustments.exposure + 8),
        contrast: Math.max(-100, currentAdjustments.contrast - 5),
        shadows: Math.min(100, currentAdjustments.shadows + 15),
        clarity: Math.min(50, currentAdjustments.clarity + 10),
      },
      'Portrait Glow'
    );
    onClose();
  };

  // Handle Style Transfer
  const handleApplyStyle = (styleId: string) => {
    if (styleId === 'cinematic') {
      onApplyAdjustments(
        {
          ...currentAdjustments,
          contrast: 25,
          saturation: -15,
          temperature: -10,
          tint: 15,
          vignette: 30,
          grain: 20,
          sharpness: 25,
        },
        'Cinematic Art'
      );
    } else if (styleId === 'anime') {
      onApplyAdjustments(
        {
          ...currentAdjustments,
          saturation: 45,
          contrast: 30,
          vibrance: 40,
          clarity: 35,
          temperature: 10,
          sharpness: 35,
        },
        'Anime Vivid'
      );
    } else if (styleId === 'oil') {
      onApplyAdjustments(
        {
          ...currentAdjustments,
          saturation: 25,
          contrast: 22,
          temperature: 20,
          clarity: 45,
          fade: 20,
          grain: 40,
        },
        'Oil Impressionist'
      );
    } else if (styleId === 'watercolor') {
      onApplyAdjustments(
        {
          ...currentAdjustments,
          brightness: 15,
          contrast: -10,
          saturation: 20,
          vibrance: 25,
          fade: 30,
          blur: 4,
          grain: 15,
        },
        'Soft Watercolor'
      );
    }
    onClose();
  };

  const navItems = [
    { id: 'assistant', label: t.aiAssistant, icon: <Sparkles className="w-4 h-4 text-purple-400" /> },
    { id: 'remove-bg', label: t.aiBgRemover, icon: <Scissors className="w-4 h-4 text-pink-400" /> },
    { id: 'enhance', label: t.enhancePhoto, icon: <Flame className="w-4 h-4 text-emerald-400" /> },
    { id: 'eraser', label: t.aiEraser, icon: <Eraser className="w-4 h-4 text-amber-400" /> },
    { id: 'portrait', label: t.portraitRetouch, icon: <UserCheck className="w-4 h-4 text-violet-400" /> },
    { id: 'style', label: t.photoToArt, icon: <Paintbrush className="w-4 h-4 text-cyan-400" /> },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 select-none">
      <div className="w-full sm:max-w-xl bg-[#0e121e] border border-purple-500/30 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center">
              <Wand2 className="w-4 h-4 text-purple-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-white">
                PIXORA <span className="text-purple-400">AI Suite</span>
              </h3>
              <p className="text-[11px] text-slate-400">Pro-grade image synthesis & tools</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation Chips */}
        <div className="flex items-center gap-1.5 px-4 py-2 border-b border-slate-800/80 overflow-x-auto bg-[#0b0d14]/60">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                activeTab === item.id
                  ? 'bg-purple-600 text-white border-purple-400 shadow-sm'
                  : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          ))}
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* TAB 1: AI ASSISTANT */}
          {activeTab === 'assistant' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  {t.aiAssistant}
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {t.aiAssistantDesc}
                </p>
              </div>

              {/* Preset suggestion chips */}
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Make this photo cinematic teal and orange',
                  'Warm golden hour sunset with rich contrast',
                  'Soft portrait lighting with brightened face',
                  'High contrast dramatic black and white',
                  'Moody vintage 80s film with warm grain',
                ].map((s, i) => (
                  <button
                    key={i}
                    onClick={() => setAssistantPrompt(s)}
                    className="text-[11px] bg-slate-900 border border-slate-800 hover:border-purple-500/50 text-slate-300 px-2.5 py-1 rounded-lg transition-colors text-left"
                  >
                    "{s}"
                  </button>
                ))}
              </div>

              {/* Prompt Input Form */}
              <form onSubmit={handleAssistantSubmit} className="space-y-3">
                <div className="relative">
                  <textarea
                    rows={3}
                    value={assistantPrompt}
                    onChange={(e) => setAssistantPrompt(e.target.value)}
                    placeholder={t.aiAssistantPlaceholder}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-2xl p-3 text-xs text-slate-200 placeholder-slate-500 focus:outline-none resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={!assistantPrompt.trim() || isAssistantLoading}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 disabled:opacity-50 transition-all active:scale-[0.98]"
                >
                  {isAssistantLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-purple-200" />
                      <span>{t.generating}</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>{t.applyAiEdits}</span>
                    </>
                  )}
                </button>
              </form>

              {assistantExplanation && (
                <div className="p-3 bg-purple-950/30 border border-purple-500/30 rounded-2xl text-xs text-purple-200">
                  <span className="font-bold block mb-1">AI Action Plan:</span>
                  {assistantExplanation}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: BACKGROUND REMOVER */}
          {activeTab === 'remove-bg' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Scissors className="w-4 h-4 text-pink-400" />
                  {t.aiBgRemover}
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  {t.aiBgRemoverDesc}
                </p>
              </div>

              {/* Sensitivity slider */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-300">
                  <span>Foreground Edge Sensitivity</span>
                  <span className="font-mono text-purple-400">{bgSensitivity}%</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={90}
                  value={bgSensitivity}
                  onChange={(e) => setBgSensitivity(Number(e.target.value))}
                  className="w-full"
                />
              </div>

              {/* Background Replacement Options */}
              <div className="space-y-2">
                <span className="text-xs font-semibold text-slate-400 block">
                  Replace Background With:
                </span>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'transparent', label: 'Alpha PNG' },
                    { id: 'solid', label: 'Solid Color' },
                    { id: 'gradient', label: 'Studio Grad' },
                    { id: 'ai', label: 'Gemini AI' },
                  ].map((b) => (
                    <button
                      key={b.id}
                      onClick={() => setBgType(b.id as any)}
                      className={`p-2 rounded-xl text-xs font-semibold border text-center transition-all ${
                        bgType === b.id
                          ? 'bg-purple-600 text-white border-purple-400'
                          : 'bg-slate-900 text-slate-400 border-slate-800'
                      }`}
                    >
                      {b.label}
                    </button>
                  ))}
                </div>

                {bgType === 'solid' && (
                  <div className="flex items-center gap-2 pt-2">
                    <span className="text-xs text-slate-400">Color:</span>
                    <input
                      type="color"
                      value={solidColor}
                      onChange={(e) => setSolidColor(e.target.value)}
                      className="w-8 h-8 rounded border border-slate-700 cursor-pointer bg-transparent"
                    />
                    <span className="font-mono text-xs text-slate-300">{solidColor}</span>
                  </div>
                )}

                {bgType === 'gradient' && (
                  <div className="flex items-center gap-2 pt-2">
                    {['sunset', 'ocean', 'studio-dark'].map((grad) => (
                      <button
                        key={grad}
                        onClick={() => setGradientType(grad)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium border capitalize ${
                          gradientType === grad
                            ? 'border-purple-400 text-white bg-purple-600/30'
                            : 'border-slate-800 text-slate-400 bg-slate-900'
                        }`}
                      >
                        {grad}
                      </button>
                    ))}
                  </div>
                )}

                {bgType === 'ai' && (
                  <div className="space-y-2 pt-2">
                    <textarea
                      rows={2}
                      value={aiBgPrompt}
                      onChange={(e) => setAiBgPrompt(e.target.value)}
                      placeholder="Describe background scene..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 resize-none"
                    />
                    <button
                      onClick={handleGenerateAiBackground}
                      disabled={isAiBgLoading}
                      className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {isAiBgLoading ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Generating Backdrop...</span>
                        </>
                      ) : (
                        <span>Generate with Gemini</span>
                      )}
                    </button>
                    {aiBgError && (
                      <p className="text-[11px] text-amber-300 leading-tight">
                        {aiBgError}
                      </p>
                    )}
                  </div>
                )}
              </div>

              <button
                onClick={handleApplyBackgroundRemoval}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-pink-600/20 active:scale-[0.98]"
              >
                <Check className="w-4 h-4" />
                <span>Apply Cutout & Background</span>
              </button>
            </div>
          )}

          {/* TAB 3: PHOTO ENHANCER */}
          {activeTab === 'enhance' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-emerald-400" />
                  {t.enhancePhoto}
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  {t.aiEnhancerDesc}
                </p>
              </div>

              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-xs text-slate-300">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>3x Unsharp convolution clarity enhancement</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-300">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Dynamic shadow lifting & highlight recovery</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-300">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Non-linear vibrance & white point expansion</span>
                </div>
              </div>

              <button
                onClick={handleEnhancePhoto}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 active:scale-[0.98]"
              >
                <Flame className="w-4 h-4" />
                <span>Enhance Image Quality Now</span>
              </button>
            </div>
          )}

          {/* TAB 4: OBJECT ERASER */}
          {activeTab === 'eraser' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Eraser className="w-4 h-4 text-amber-400" />
                  {t.aiEraser}
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {t.aiEraserDesc}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 text-xs text-amber-200/90 leading-relaxed">
                Click "Launch Brush Mode" to brush directly over people, blemishes, or power lines on the photo canvas. The diffusion inpainting algorithm will blend surrounding pixels to erase the area seamlessly.
              </div>

              <button
                onClick={() => {
                  onStartEraserMode();
                  onClose();
                }}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-600/25 active:scale-[0.98]"
              >
                <Eraser className="w-4 h-4" />
                <span>Launch Eraser Brush</span>
              </button>
            </div>
          )}

          {/* TAB 5: PORTRAIT RETOUCH */}
          {activeTab === 'portrait' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-violet-400" />
                  {t.portraitRetouch}
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  {t.portraitRetouchDesc}
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-xs text-slate-300">
                  <span>Skin Smoothing Intensity</span>
                  <span className="font-mono text-violet-400">{skinSmoothIntensity}%</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={100}
                  value={skinSmoothIntensity}
                  onChange={(e) => setSkinSmoothIntensity(Number(e.target.value))}
                  className="w-full"
                />
              </div>

              <div className="p-3 bg-slate-900 border border-slate-800 rounded-2xl text-[11px] text-slate-400">
                Skin tone detection isolates facial regions and softens blemishes while keeping eyes, lips, and facial contours sharp and authentic.
              </div>

              <button
                onClick={handlePortraitRetouch}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-violet-600/25 active:scale-[0.98]"
              >
                <UserCheck className="w-4 h-4" />
                <span>Apply Natural Retouch</span>
              </button>
            </div>
          )}

          {/* TAB 6: STYLE TRANSFER */}
          {activeTab === 'style' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Paintbrush className="w-4 h-4 text-cyan-400" />
                  {t.photoToArt}
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  {t.styleTransferDesc}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {[
                  {
                    id: 'cinematic',
                    title: 'Cinematic Movie',
                    desc: 'Teal/Orange LUT & anamorphic contrast',
                    color: 'from-blue-600/30 to-amber-600/30',
                  },
                  {
                    id: 'anime',
                    title: 'Anime Vivid',
                    desc: 'Vibrant cell shading and hyper saturation',
                    color: 'from-pink-600/30 to-purple-600/30',
                  },
                  {
                    id: 'oil',
                    title: 'Oil Painting',
                    desc: 'Impressionist brush stroke tones & warmth',
                    color: 'from-amber-600/30 to-yellow-600/30',
                  },
                  {
                    id: 'watercolor',
                    title: 'Watercolor Dream',
                    desc: 'Soft paper bleed with pastel fade',
                    color: 'from-cyan-600/30 to-emerald-600/30',
                  },
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => handleApplyStyle(s.id)}
                    className="p-3 rounded-2xl bg-[#121624] border border-slate-800 hover:border-cyan-500/50 text-left transition-all hover:scale-[1.02] active:scale-95 group"
                  >
                    <div className="font-bold text-xs text-white group-hover:text-cyan-300">
                      {s.title}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-1 line-clamp-2">
                      {s.desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
