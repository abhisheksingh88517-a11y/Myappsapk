import React, { useState, useRef, useEffect } from 'react';
import {
  LayoutGrid,
  Plus,
  Trash2,
  Download,
  ArrowLeft,
  Sliders,
  Check,
  Sparkles,
} from 'lucide-react';
import { Language } from '../types';
import { useTranslation } from '../utils/translations';
import { SAMPLE_IMAGES } from '../utils/sampleImages';

interface CollageMakerProps {
  onBack: () => void;
  onOpenInEditor: (dataUrl: string) => void;
  lang: Language;
}

export const CollageMaker: React.FC<CollageMakerProps> = ({
  onBack,
  onOpenInEditor,
  lang,
}) => {
  const t = useTranslation(lang);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Selected photos for collage (initial with 4 high-res sample photos)
  const [photos, setPhotos] = useState<string[]>([
    SAMPLE_IMAGES[0].url,
    SAMPLE_IMAGES[1].url,
    SAMPLE_IMAGES[2].url,
    SAMPLE_IMAGES[3].url,
  ]);

  // Styling
  const [layout, setLayout] = useState<'2-vert' | '2-horiz' | '3-tri' | '4-grid' | '6-grid'>('4-grid');
  const [gap, setGap] = useState(8);
  const [borderRadius, setBorderRadius] = useState(12);
  const [bgColor, setBgColor] = useState('#0b0d14');
  const [aspect, setAspect] = useState<'1:1' | '4:5' | '9:16' | '16:9'>('1:1');

  const handleAddPhotos = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newPhotos: string[] = [];
    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPhotos((prev) => [...prev, reader.result as string].slice(0, 9));
        }
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  };

  const removePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  };

  // Render collage to canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || photos.length === 0) return;

    let targetWidth = 1200;
    let targetHeight = 1200;
    if (aspect === '4:5') targetHeight = 1500;
    if (aspect === '9:16') targetHeight = 2133;
    if (aspect === '16:9') {
      targetWidth = 1600;
      targetHeight = 900;
    }

    canvas.width = targetWidth;
    canvas.height = targetHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, targetWidth, targetHeight);

    // Compute slot rectangles based on layout
    const slots: { x: number; y: number; w: number; h: number }[] = [];
    const count = Math.min(photos.length, 9);
    const pGap = gap * 2; // scaled to 1200px

    if (layout === '2-horiz' || count === 2) {
      const w = (targetWidth - pGap * 3) / 2;
      const h = targetHeight - pGap * 2;
      slots.push({ x: pGap, y: pGap, w, h });
      slots.push({ x: pGap * 2 + w, y: pGap, w, h });
    } else if (layout === '2-vert') {
      const w = targetWidth - pGap * 2;
      const h = (targetHeight - pGap * 3) / 2;
      slots.push({ x: pGap, y: pGap, w, h });
      slots.push({ x: pGap, y: pGap * 2 + h, w, h });
    } else if (layout === '3-tri') {
      const topW = targetWidth - pGap * 2;
      const topH = (targetHeight - pGap * 3) / 2;
      const bW = (targetWidth - pGap * 3) / 2;
      const bH = topH;
      slots.push({ x: pGap, y: pGap, w: topW, h: topH });
      slots.push({ x: pGap, y: pGap * 2 + topH, w: bW, h: bH });
      slots.push({ x: pGap * 2 + bW, y: pGap * 2 + topH, w: bW, h: bH });
    } else if (layout === '6-grid' && count >= 5) {
      const cols = 3;
      const rows = 2;
      const w = (targetWidth - pGap * (cols + 1)) / cols;
      const h = (targetHeight - pGap * (rows + 1)) / rows;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          slots.push({
            x: pGap + c * (w + pGap),
            y: pGap + r * (h + pGap),
            w,
            h,
          });
        }
      }
    } else {
      // 4-grid default 2x2
      const w = (targetWidth - pGap * 3) / 2;
      const h = (targetHeight - pGap * 3) / 2;
      slots.push({ x: pGap, y: pGap, w, h });
      slots.push({ x: pGap * 2 + w, y: pGap, w, h });
      slots.push({ x: pGap, y: pGap * 2 + h, w, h });
      slots.push({ x: pGap * 2 + w, y: pGap * 2 + h, w, h });
    }

    // Load and draw images into slots with aspect fill and rounded corners
    let loadedCount = 0;
    const numToRender = Math.min(photos.length, slots.length);

    slots.slice(0, numToRender).forEach((slot, idx) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        ctx.save();
        // Rounded clip
        ctx.beginPath();
        const r = borderRadius * 2;
        ctx.roundRect(slot.x, slot.y, slot.w, slot.h, r);
        ctx.clip();

        // Cover fill
        const imgAspect = img.width / img.height;
        const slotAspect = slot.w / slot.h;
        let renderW = slot.w;
        let renderH = slot.h;
        let offsetX = 0;
        let offsetY = 0;

        if (imgAspect > slotAspect) {
          renderW = slot.h * imgAspect;
          offsetX = (slot.w - renderW) / 2;
        } else {
          renderH = slot.w / imgAspect;
          offsetY = (slot.h - renderH) / 2;
        }

        ctx.drawImage(img, slot.x + offsetX, slot.y + offsetY, renderW, renderH);
        ctx.restore();

        loadedCount++;
      };
      img.src = photos[idx];
    });
  }, [photos, layout, gap, borderRadius, bgColor, aspect]);

  const handleExportCollage = () => {
    if (!canvasRef.current) return;
    const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.95);
    const link = document.createElement('a');
    link.download = `pixora-collage-${Date.now()}.jpg`;
    link.href = dataUrl;
    link.click();
  };

  const handleSendToEditor = () => {
    if (!canvasRef.current) return;
    const dataUrl = canvasRef.current.toDataURL('image/png');
    onOpenInEditor(dataUrl);
  };

  return (
    <div className="min-h-screen bg-[#0b0d14] text-slate-100 flex flex-col justify-between select-none">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*"
        className="hidden"
        onChange={handleAddPhotos}
      />

      {/* Header */}
      <div className="sticky top-0 z-30 bg-[#0e121e]/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Home</span>
        </button>

        <div className="flex items-center gap-2">
          <LayoutGrid className="w-4 h-4 text-purple-400" />
          <span className="font-extrabold text-sm text-white">{t.collageMaker}</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSendToEditor}
            className="flex items-center gap-1 bg-purple-600/30 border border-purple-500/50 text-purple-300 text-xs font-semibold px-2.5 py-1.5 rounded-xl hover:bg-purple-600 hover:text-white transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Edit</span>
          </button>
          <button
            onClick={handleExportCollage}
            className="flex items-center gap-1 bg-gradient-to-r from-purple-600 to-cyan-500 text-white text-xs font-semibold px-3 py-1.5 rounded-xl shadow transition-transform active:scale-95"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Save</span>
          </button>
        </div>
      </div>

      {/* Main Preview Area */}
      <div className="flex-1 flex items-center justify-center p-4">
        <canvas
          ref={canvasRef}
          className="max-h-[50vh] max-w-full rounded-2xl shadow-2xl border border-slate-800 object-contain"
        />
      </div>

      {/* Bottom Controls Sheet */}
      <div className="bg-[#0e121e] border-t border-slate-800 p-4 space-y-4 max-w-xl mx-auto w-full">
        {/* Template Layout selector */}
        <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1">
          {[
            { id: '2-horiz', label: '2 Split V' },
            { id: '2-vert', label: '2 Split H' },
            { id: '3-tri', label: '3 Trio' },
            { id: '4-grid', label: '4 Grid' },
            { id: '6-grid', label: '6 Mosaic' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setLayout(item.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap border transition-all ${
                layout === item.id
                  ? 'bg-purple-600 text-white border-purple-400'
                  : 'bg-slate-900 text-slate-400 border-slate-800'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Sliders: Spacing & Radius */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Gap Spacing</span>
              <span className="font-mono text-purple-300">{gap}px</span>
            </div>
            <input
              type="range"
              min={0}
              max={24}
              value={gap}
              onChange={(e) => setGap(Number(e.target.value))}
              className="w-full"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Corner Radius</span>
              <span className="font-mono text-purple-300">{borderRadius}px</span>
            </div>
            <input
              type="range"
              min={0}
              max={32}
              value={borderRadius}
              onChange={(e) => setBorderRadius(Number(e.target.value))}
              className="w-full"
            />
          </div>
        </div>

        {/* Photo tray with add/remove */}
        <div className="flex items-center gap-2 overflow-x-auto py-1">
          {photos.map((p, idx) => (
            <div
              key={idx}
              className="relative w-14 h-14 rounded-xl overflow-hidden border border-slate-700 flex-shrink-0 group"
            >
              <img src={p} alt="slot" className="w-full h-full object-cover" />
              <button
                onClick={() => removePhoto(idx)}
                className="absolute inset-0 bg-red-950/80 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="w-4 h-4 text-red-400" />
              </button>
            </div>
          ))}

          {photos.length < 9 && (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-14 h-14 rounded-xl border-2 border-dashed border-slate-700 hover:border-purple-500 flex flex-col items-center justify-center text-slate-400 hover:text-white flex-shrink-0 transition-colors"
            >
              <Plus className="w-5 h-5" />
              <span className="text-[9px]">Add</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
