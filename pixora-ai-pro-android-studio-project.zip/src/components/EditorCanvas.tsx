import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  ImageAdjustments,
  GeometryTransform,
  FilterPreset,
  TextLayer,
  StickerLayer,
} from '../types';
import { renderAdjustedImage } from '../utils/imageProcessing';
import { Eye, SplitSquareVertical, Move, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';

interface EditorCanvasProps {
  originalImage: HTMLImageElement | null;
  adjustments: ImageAdjustments;
  geometry: GeometryTransform;
  activeFilter?: FilterPreset;
  filterIntensity: number;
  textLayers: TextLayer[];
  stickerLayers: StickerLayer[];
  maskCanvas: HTMLCanvasElement | null;
  backgroundStyle: {
    type: 'none' | 'color' | 'gradient' | 'image';
    value?: string;
  };
  isEraserMode?: boolean;
  eraserBrushSize?: number;
  onEraserDraw?: (maskCanvas: HTMLCanvasElement) => void;
  onCanvasReady?: (canvas: HTMLCanvasElement) => void;
  onSelectTextLayer?: (layerId: string) => void;
}

export const EditorCanvas: React.FC<EditorCanvasProps> = ({
  originalImage,
  adjustments,
  geometry,
  activeFilter,
  filterIntensity,
  textLayers,
  stickerLayers,
  maskCanvas,
  backgroundStyle,
  isEraserMode = false,
  eraserBrushSize = 25,
  onEraserDraw,
  onCanvasReady,
  onSelectTextLayer,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const targetCanvasRef = useRef<HTMLCanvasElement>(null);
  const originalCanvasRef = useRef<HTMLCanvasElement>(null);
  const eraserMaskCanvasRef = useRef<HTMLCanvasElement>(null);

  // Before / After comparison states
  const [showOriginal, setShowOriginal] = useState(false);
  const [splitSliderActive, setSplitSliderActive] = useState(false);
  const [splitPosition, setSplitPosition] = useState(0.5); // 0 to 1

  // Zoom & Pan state
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const isPanningRef = useRef(false);
  const panStartRef = useRef({ x: 0, y: 0 });

  // Eraser drawing state
  const isDrawingEraserRef = useRef(false);

  // Render processed photo
  const updateRender = useCallback(() => {
    if (!originalImage || !targetCanvasRef.current) return;

    // Render adjusted version
    renderAdjustedImage(
      originalImage,
      targetCanvasRef.current,
      adjustments,
      geometry,
      activeFilter,
      filterIntensity,
      maskCanvas,
      {
        backgroundStyle,
      }
    );

    // Render unmodified original for before/after comparison
    if (originalCanvasRef.current) {
      renderAdjustedImage(
        originalImage,
        originalCanvasRef.current,
        {
          brightness: 0, exposure: 0, contrast: 0, saturation: 0, vibrance: 0,
          temperature: 0, tint: 0, highlights: 0, shadows: 0, whites: 0,
          blacks: 0, gamma: 0, hue: 0, sharpness: 0, clarity: 0, fade: 0,
          vignette: 0, grain: 0, blur: 0,
        },
        geometry
      );
    }

    if (onCanvasReady && targetCanvasRef.current) {
      onCanvasReady(targetCanvasRef.current);
    }
  }, [
    originalImage,
    adjustments,
    geometry,
    activeFilter,
    filterIntensity,
    maskCanvas,
    backgroundStyle,
    onCanvasReady,
  ]);

  useEffect(() => {
    updateRender();
  }, [updateRender]);

  // Setup eraser overlay dimensions
  useEffect(() => {
    if (!targetCanvasRef.current || !eraserMaskCanvasRef.current) return;
    eraserMaskCanvasRef.current.width = targetCanvasRef.current.width;
    eraserMaskCanvasRef.current.height = targetCanvasRef.current.height;
  }, [originalImage, geometry]);

  // Reset zoom & pan
  const handleResetZoomPan = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Dragging split slider
  const handleSplitDividerMove = (e: React.PointerEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(rect.width, e.clientX - rect.left));
    setSplitPosition(x / rect.width);
  };

  // Eraser brush handlers
  const handleEraserPointerDown = (e: React.PointerEvent) => {
    if (!isEraserMode || !eraserMaskCanvasRef.current) return;
    isDrawingEraserRef.current = true;
    drawEraserStroke(e);
  };

  const handleEraserPointerMove = (e: React.PointerEvent) => {
    if (!isDrawingEraserRef.current || !isEraserMode) return;
    drawEraserStroke(e);
  };

  const handleEraserPointerUp = () => {
    if (isDrawingEraserRef.current && onEraserDraw && eraserMaskCanvasRef.current) {
      onEraserDraw(eraserMaskCanvasRef.current);
    }
    isDrawingEraserRef.current = false;
  };

  const drawEraserStroke = (e: React.PointerEvent) => {
    const canvas = eraserMaskCanvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = 'rgba(239, 68, 68, 0.65)'; // Semi-transparent red highlight
    ctx.beginPath();
    ctx.arc(x, y, (eraserBrushSize * scaleX) / 2, 0, Math.PI * 2);
    ctx.fill();
  };

  // Pan handlers when not in eraser mode
  const handlePanDown = (e: React.PointerEvent) => {
    if (isEraserMode) return;
    if (e.target !== containerRef.current && e.target !== targetCanvasRef.current) return;
    isPanningRef.current = true;
    panStartRef.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handlePanMove = (e: React.PointerEvent) => {
    if (!isPanningRef.current) return;
    setPan({
      x: e.clientX - panStartRef.current.x,
      y: e.clientY - panStartRef.current.y,
    });
  };

  const handlePanUp = () => {
    isPanningRef.current = false;
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full flex items-center justify-center bg-[#07090f] overflow-hidden select-none"
      onPointerDown={handlePanDown}
      onPointerMove={handlePanMove}
      onPointerUp={handlePanUp}
    >
      {/* Subtle editor grid background */}
      <div
        className="absolute inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage:
            'radial-gradient(rgba(148, 163, 184, 0.3) 1px, transparent 1px)',
          backgroundSize: '24px 24px',
        }}
      />

      {/* Floating HUD: Zoom Controls & Before/After Buttons */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-20 pointer-events-none">
        {/* Zoom & Reset */}
        <div className="flex items-center gap-1.5 bg-[#121624]/90 border border-slate-800 p-1 rounded-full shadow-lg pointer-events-auto">
          <button
            onClick={() => setZoom((z) => Math.min(3, z + 0.25))}
            className="w-7 h-7 rounded-full hover:bg-slate-800 flex items-center justify-center text-slate-300 hover:text-white"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <span className="text-[11px] font-mono font-semibold px-1 text-slate-400">
            {Math.round(zoom * 100)}%
          </span>
          <button
            onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}
            className="w-7 h-7 rounded-full hover:bg-slate-800 flex items-center justify-center text-slate-300 hover:text-white"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          {(zoom !== 1 || pan.x !== 0 || pan.y !== 0) && (
            <button
              onClick={handleResetZoomPan}
              className="w-7 h-7 rounded-full hover:bg-purple-600/30 text-purple-400 flex items-center justify-center"
              title="Reset Zoom/Pan"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Before / After Comparison Controls */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Split Screen Slider Toggle */}
          <button
            onClick={() => setSplitSliderActive(!splitSliderActive)}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full border shadow-lg transition-all ${
              splitSliderActive
                ? 'bg-purple-600 text-white border-purple-400'
                : 'bg-[#121624]/90 text-slate-300 border-slate-800 hover:border-slate-700'
            }`}
            title="Interactive Split Comparison Slider"
          >
            <SplitSquareVertical className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Split View</span>
          </button>

          {/* Press and Hold Original */}
          <button
            onPointerDown={() => setShowOriginal(true)}
            onPointerUp={() => setShowOriginal(false)}
            onPointerLeave={() => setShowOriginal(false)}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full border shadow-lg transition-all active:scale-95 ${
              showOriginal
                ? 'bg-amber-500 text-black border-amber-300'
                : 'bg-[#121624]/90 text-slate-300 border-slate-800 hover:border-slate-700'
            }`}
            title="Hold down to preview unedited original image"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Hold Original</span>
          </button>
        </div>
      </div>

      {/* Main Scalable Viewport */}
      <div
        className="relative max-w-[92%] max-h-[85%] flex items-center justify-center transition-transform duration-75 ease-out shadow-2xl"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
        }}
      >
        {/* Processed Adjusted Image Canvas */}
        <canvas
          ref={targetCanvasRef}
          className="max-w-full max-h-[72vh] object-contain rounded-xl shadow-2xl border border-slate-800/80"
          style={{
            display: showOriginal ? 'none' : 'block',
          }}
        />

        {/* Unedited Original Image Canvas (for Press-and-Hold or Split View) */}
        <canvas
          ref={originalCanvasRef}
          className="max-w-full max-h-[72vh] object-contain rounded-xl shadow-2xl border border-slate-800/80"
          style={{
            display: showOriginal ? 'block' : 'none',
          }}
        />

        {/* Split Screen Slider Overlay */}
        {splitSliderActive && (
          <div
            className="absolute inset-0 overflow-hidden pointer-events-none rounded-xl"
            style={{
              clipPath: `inset(0 ${(1 - splitPosition) * 100}% 0 0)`,
            }}
          >
            <canvas
              ref={(c) => {
                if (c && originalCanvasRef.current) {
                  c.width = originalCanvasRef.current.width;
                  c.height = originalCanvasRef.current.height;
                  const ctx = c.getContext('2d');
                  if (ctx) ctx.drawImage(originalCanvasRef.current, 0, 0);
                }
              }}
              className="w-full h-full object-contain"
            />
          </div>
        )}

        {/* Draggable Divider Line */}
        {splitSliderActive && (
          <div
            className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-20 flex items-center justify-center shadow-[0_0_12px_rgba(255,255,255,0.8)]"
            style={{
              left: `${splitPosition * 100}%`,
            }}
            onPointerDown={(e) => {
              (e.target as HTMLElement).setPointerCapture(e.pointerId);
            }}
            onPointerMove={(e) => {
              if (e.buttons === 1) handleSplitDividerMove(e);
            }}
          >
            <div className="w-7 h-7 rounded-full bg-white text-slate-900 flex items-center justify-center shadow-lg -translate-x-1/2">
              <SplitSquareVertical className="w-4 h-4" />
            </div>
          </div>
        )}

        {/* Text Layers Overlay */}
        {textLayers.map((layer) => (
          <div
            key={layer.id}
            onClick={() => onSelectTextLayer && onSelectTextLayer(layer.id)}
            className="absolute cursor-pointer transition-transform hover:scale-105"
            style={{
              left: `${layer.x * 100}%`,
              top: `${layer.y * 100}%`,
              transform: `translate(-50%, -50%) rotate(${layer.rotation}deg)`,
              fontFamily: layer.fontFamily,
              fontSize: `${layer.fontSize}px`,
              color: layer.color,
              backgroundColor: layer.backgroundColor || 'transparent',
              opacity: layer.opacity,
              fontWeight: layer.bold ? 'bold' : 'normal',
              fontStyle: layer.italic ? 'italic' : 'normal',
              textShadow: layer.outlineColor
                ? `0 0 ${layer.outlineWidth || 2}px ${layer.outlineColor}`
                : '0 2px 8px rgba(0,0,0,0.7)',
              padding: '4px 8px',
              borderRadius: '6px',
            }}
          >
            {layer.text}
          </div>
        ))}

        {/* Sticker Layers Overlay */}
        {stickerLayers.map((sticker) => (
          <div
            key={sticker.id}
            className="absolute pointer-events-none select-none"
            style={{
              left: `${sticker.x * 100}%`,
              top: `${sticker.y * 100}%`,
              transform: `translate(-50%, -50%) rotate(${sticker.rotation}deg)`,
              opacity: sticker.opacity,
            }}
          >
            {sticker.isEmoji ? (
              <span style={{ fontSize: `${sticker.width}px` }}>
                {sticker.src}
              </span>
            ) : (
              <img
                src={sticker.src}
                alt="sticker"
                style={{
                  width: `${sticker.width}px`,
                  height: `${sticker.height}px`,
                }}
              />
            )}
          </div>
        ))}

        {/* Eraser Mask Drawing Canvas Overlay */}
        {isEraserMode && (
          <canvas
            ref={eraserMaskCanvasRef}
            className="absolute inset-0 w-full h-full cursor-crosshair z-30 touch-none"
            onPointerDown={handleEraserPointerDown}
            onPointerMove={handleEraserPointerMove}
            onPointerUp={handleEraserPointerUp}
          />
        )}
      </div>

      {/* Eraser Mode Notice */}
      {isEraserMode && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-red-600/90 text-white text-xs font-semibold px-4 py-1.5 rounded-full shadow-lg flex items-center gap-2 pointer-events-none z-20">
          <span>Brush over unwanted items to erase</span>
        </div>
      )}
    </div>
  );
};
