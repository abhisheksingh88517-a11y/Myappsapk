import React, { useState, useEffect } from 'react';
import {
  Download,
  Share2,
  CheckCircle2,
  X,
  FileImage,
  Sliders,
  Sparkles,
  Layers,
} from 'lucide-react';
import { Language, ExportHistoryItem } from '../types';
import { useTranslation } from '../utils/translations';
import { saveExportItem } from '../utils/projectStorage';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  renderedCanvas: HTMLCanvasElement | null;
  lang: Language;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  renderedCanvas,
  lang,
}) => {
  const t = useTranslation(lang);
  const [format, setFormat] = useState<'jpeg' | 'png' | 'webp'>('jpeg');
  const [quality, setQuality] = useState<number>(0.92);
  const [resolutionPreset, setResolutionPreset] = useState<string>('original');
  const [customFilename, setCustomFilename] = useState(`pixora_${Date.now()}`);
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [estimatedSizeKb, setEstimatedSizeKb] = useState<number>(0);

  useEffect(() => {
    if (!renderedCanvas) return;
    // Calculate preview file size
    const factor = format === 'png' ? 1.8 : quality;
    const pixels = renderedCanvas.width * renderedCanvas.height;
    const est = Math.round((pixels * 3 * factor * 0.12) / 1024);
    setEstimatedSizeKb(Math.max(120, est));
  }, [renderedCanvas, format, quality]);

  if (!isOpen || !renderedCanvas) return null;

  const presets = [
    { id: 'original', label: 'Original Full Res' },
    { id: 'insta-square', label: 'Instagram (1080x1080)', w: 1080, h: 1080 },
    { id: 'story-916', label: 'Story / Reel (1080x1920)', w: 1080, h: 1920 },
    { id: 'youtube', label: 'YouTube (1280x720)', w: 1280, h: 720 },
    { id: '2k', label: '2K QHD (2048x1536)', w: 2048, h: 1536 },
    { id: '4k', label: '4K Ultra (3840x2160)', w: 3840, h: 2160 },
  ];

  const generateExportBlob = (): Promise<{ blob: Blob; dataUrl: string; width: number; height: number }> => {
    return new Promise((resolve) => {
      let targetW = renderedCanvas.width;
      let targetH = renderedCanvas.height;

      const chosenPreset = presets.find((p) => p.id === resolutionPreset);
      if (chosenPreset && chosenPreset.w && chosenPreset.h) {
        targetW = chosenPreset.w;
        targetH = chosenPreset.h;
      }

      const exportCanvas = document.createElement('canvas');
      exportCanvas.width = targetW;
      exportCanvas.height = targetH;
      const ctx = exportCanvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(renderedCanvas, 0, 0, targetW, targetH);
      }

      const mime =
        format === 'png'
          ? 'image/png'
          : format === 'webp'
          ? 'image/webp'
          : 'image/jpeg';

      const dataUrl = exportCanvas.toDataURL(mime, quality);
      exportCanvas.toBlob(
        (blob) => {
          if (blob) {
            resolve({ blob, dataUrl, width: targetW, height: targetH });
          }
        },
        mime,
        quality
      );
    });
  };

  const handleSaveToDevice = async () => {
    setIsExporting(true);
    try {
      const { blob, dataUrl, width, height } = await generateExportBlob();
      const filename = `${customFilename}.${format}`;

      const link = document.createElement('a');
      link.download = filename;
      link.href = URL.createObjectURL(blob);
      link.click();

      // Record export in history
      const historyItem: ExportHistoryItem = {
        id: 'export-' + Date.now(),
        dataUrl,
        filename,
        format,
        width,
        height,
        fileSizeBytes: blob.size,
        exportedAt: Date.now(),
      };
      saveExportItem(historyItem);

      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (err) {
      console.error('Export failed:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handleAndroidShare = async () => {
    if (!navigator.share) {
      handleSaveToDevice();
      return;
    }

    try {
      const { blob } = await generateExportBlob();
      const file = new File([blob], `${customFilename}.${format}`, {
        type: blob.type,
      });
      await navigator.share({
        files: [file],
        title: 'PIXORA AI Edited Photo',
        text: 'Edited with PIXORA AI Pro',
      });
    } catch (err) {
      // User cancelled or share not supported
      handleSaveToDevice();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 select-none">
      <div className="w-full sm:max-w-md bg-[#0e121e] border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Download className="w-5 h-5 text-purple-400" />
            <h3 className="font-extrabold text-base text-white">
              {t.exportSettings}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {/* Filename */}
          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-1">
              File Name
            </span>
            <input
              type="text"
              value={customFilename}
              onChange={(e) => setCustomFilename(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 font-mono"
            />
          </div>

          {/* Format selector */}
          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-1.5">
              {t.imageFormat}
            </span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'jpeg', label: 'JPEG (Photo)' },
                { id: 'png', label: 'PNG (Alpha)' },
                { id: 'webp', label: 'WebP (Modern)' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFormat(f.id as any)}
                  className={`p-2.5 rounded-xl text-xs font-semibold border transition-all ${
                    format === f.id
                      ? 'bg-purple-600 text-white border-purple-400 shadow-sm'
                      : 'bg-slate-900 text-slate-400 border-slate-800'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Resolution Preset */}
          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-1.5">
              {t.resolutionPreset}
            </span>
            <select
              value={resolutionPreset}
              onChange={(e) => setResolutionPreset(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200"
            >
              {presets.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.label}
                </option>
              ))}
            </select>
          </div>

          {/* Quality Slider (for JPEG / WebP) */}
          {format !== 'png' && (
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-400">
                <span>{t.quality}</span>
                <span className="font-mono text-purple-300">
                  {Math.round(quality * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0.5}
                max={1.0}
                step={0.02}
                value={quality}
                onChange={(e) => setQuality(Number(e.target.value))}
                className="w-full"
              />
            </div>
          )}

          {/* File Size & Dimensions Info Card */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3 flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-500 block">Dimensions</span>
              <span className="font-mono font-bold text-slate-200">
                {renderedCanvas.width} × {renderedCanvas.height} px
              </span>
            </div>
            <div className="text-right">
              <span className="text-slate-500 block">{t.fileSizeEstimate}</span>
              <span className="font-mono font-bold text-cyan-300">
                ~{estimatedSizeKb > 1024 ? `${(estimatedSizeKb / 1024).toFixed(1)} MB` : `${estimatedSizeKb} KB`}
              </span>
            </div>
          </div>

          {exportSuccess && (
            <div className="bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 p-2.5 rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{t.exportSuccess}</span>
            </div>
          )}

          {/* Actions */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              onClick={handleSaveToDevice}
              disabled={isExporting}
              className="py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-all active:scale-[0.98] disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{t.saveToDevice}</span>
            </button>

            <button
              onClick={handleAndroidShare}
              disabled={isExporting}
              className="py-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50"
            >
              <Share2 className="w-4 h-4 text-cyan-400" />
              <span>{t.share}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
