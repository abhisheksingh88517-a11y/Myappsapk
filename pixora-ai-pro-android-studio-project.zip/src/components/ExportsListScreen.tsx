import React, { useState, useEffect } from 'react';
import { ExportHistoryItem, Language } from '../types';
import { getAllExports, deleteExportItem } from '../utils/projectStorage';
import { ArrowLeft, Download, Trash2, Share2, Image as ImageIcon } from 'lucide-react';
import { useTranslation } from '../utils/translations';

interface ExportsListScreenProps {
  onBack: () => void;
  lang: Language;
}

export const ExportsListScreen: React.FC<ExportsListScreenProps> = ({ onBack, lang }) => {
  const t = useTranslation(lang);
  const [exports, setExports] = useState<ExportHistoryItem[]>([]);

  useEffect(() => {
    setExports(getAllExports());
  }, []);

  const handleDelete = (id: string) => {
    deleteExportItem(id);
    setExports((prev) => prev.filter((e) => e.id !== id));
  };

  const handleDownload = (item: ExportHistoryItem) => {
    const link = document.createElement('a');
    link.download = item.filename;
    link.href = item.dataUrl;
    link.click();
  };

  return (
    <div className="min-h-screen bg-[#0b0d14] text-slate-100 flex flex-col justify-between select-none">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-[#0e121e]/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Home</span>
        </button>

        <h3 className="font-extrabold text-sm text-white">{t.myExports}</h3>
        <span className="text-xs font-mono text-purple-400">{exports.length} photos</span>
      </div>

      {/* Content */}
      <div className="p-4 max-w-xl mx-auto w-full flex-1">
        {exports.length === 0 ? (
          <div className="text-center py-20 text-slate-500 space-y-3">
            <ImageIcon className="w-12 h-12 text-slate-700 mx-auto" />
            <p className="text-xs">{t.emptyExports}</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {exports.map((item) => (
              <div
                key={item.id}
                className="bg-[#121624] border border-slate-800 rounded-2xl overflow-hidden flex flex-col"
              >
                <div className="aspect-square bg-slate-900 relative">
                  <img
                    src={item.dataUrl}
                    alt={item.filename}
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute top-1.5 right-1.5 bg-black/70 uppercase text-[9px] font-mono px-1.5 py-0.5 rounded text-white">
                    {item.format}
                  </span>
                </div>

                <div className="p-2.5 flex items-center justify-between">
                  <div className="truncate mr-2">
                    <span className="text-xs font-semibold text-white block truncate">
                      {item.filename}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {item.width}x{item.height} • {(item.fileSizeBytes / 1024).toFixed(0)} KB
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleDownload(item)}
                      className="p-1.5 rounded-lg bg-purple-600/20 text-purple-300 hover:bg-purple-600 hover:text-white transition-colors"
                      title="Download"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(item.id)}
                      className="p-1.5 rounded-lg bg-rose-950/40 text-rose-400 hover:bg-rose-900 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
