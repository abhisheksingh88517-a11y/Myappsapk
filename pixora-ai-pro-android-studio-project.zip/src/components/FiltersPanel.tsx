import React, { useState } from 'react';
import { FilterPreset, Language } from '../types';
import { FILTER_PRESETS } from '../utils/imageProcessing';
import { SlidersHorizontal, Check } from 'lucide-react';

interface FiltersPanelProps {
  activeFilterId: string;
  filterIntensity: number;
  onSelectFilter: (filter: FilterPreset) => void;
  onChangeIntensity: (intensity: number) => void;
  lang: Language;
}

export const FiltersPanel: React.FC<FiltersPanelProps> = ({
  activeFilterId,
  filterIntensity,
  onSelectFilter,
  onChangeIntensity,
  lang,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Cinematic', 'Portrait', 'Warm', 'Moody', 'Vintage', 'B&W', 'Creative'];

  const filteredPresets =
    selectedCategory === 'All'
      ? FILTER_PRESETS
      : FILTER_PRESETS.filter((p) => p.category === selectedCategory);

  return (
    <div className="bg-[#0e121e] border-t border-slate-800 flex flex-col p-4 select-none space-y-3">
      {/* Intensity Slider if non-original filter is active */}
      {activeFilterId !== 'original' && (
        <div className="flex items-center gap-3 bg-slate-900/90 border border-slate-800 px-3.5 py-2 rounded-2xl">
          <SlidersHorizontal className="w-4 h-4 text-purple-400 flex-shrink-0" />
          <span className="text-xs font-semibold text-slate-300 flex-shrink-0">
            Intensity
          </span>
          <input
            type="range"
            min={0}
            max={100}
            value={filterIntensity}
            onChange={(e) => onChangeIntensity(Number(e.target.value))}
            className="flex-1"
          />
          <span className="font-mono text-xs font-bold text-purple-300 w-8 text-right">
            {filterIntensity}%
          </span>
        </div>
      )}

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 -mx-1 px-1">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all border ${
              selectedCategory === cat
                ? 'bg-purple-600 text-white border-purple-400 shadow-sm'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Horizontal Filter Thumbnails Carousel */}
      <div className="flex items-center gap-3 overflow-x-auto py-1 -mx-1 px-1">
        {filteredPresets.map((preset) => {
          const isActive = activeFilterId === preset.id;
          return (
            <button
              key={preset.id}
              onClick={() => onSelectFilter(preset)}
              className="flex-shrink-0 flex flex-col items-center gap-1.5 group active:scale-95 transition-transform"
            >
              <div
                className={`w-16 h-20 rounded-2xl p-0.5 border-2 transition-all relative overflow-hidden flex items-center justify-center ${
                  isActive
                    ? 'border-purple-400 shadow-[0_0_14px_rgba(168,85,247,0.5)]'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
                style={{
                  background: `linear-gradient(135deg, ${preset.thumbnailColor} 0%, #0b0d14 100%)`,
                }}
              >
                {isActive && (
                  <div className="absolute top-1 right-1 w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center shadow">
                    <Check className="w-3 h-3" />
                  </div>
                )}
                <span className="text-[10px] font-bold text-white/90 text-center px-1">
                  {lang === 'hi' ? preset.nameHi : preset.name}
                </span>
              </div>
              <span
                className={`text-[10px] font-medium truncate max-w-[64px] ${
                  isActive ? 'text-purple-300 font-bold' : 'text-slate-400'
                }`}
              >
                {lang === 'hi' ? preset.nameHi : preset.name}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
