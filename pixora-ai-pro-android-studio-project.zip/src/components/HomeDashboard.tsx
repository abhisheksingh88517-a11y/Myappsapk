import React, { useRef } from 'react';
import {
  Sparkles,
  Image as ImageIcon,
  Wand2,
  Scissors,
  Eraser,
  Flame,
  UserCheck,
  Palette,
  LayoutGrid,
  Paintbrush,
  Type,
  Clock,
  Download,
  Settings,
  Camera,
  FolderDown,
  Rotate3d,
  Languages,
  ChevronRight,
} from 'lucide-react';
import { Language, ProjectState, ExportHistoryItem } from '../types';
import { useTranslation } from '../utils/translations';
import { SAMPLE_IMAGES, SampleImage } from '../utils/sampleImages';

interface HomeDashboardProps {
  onSelectPhoto: (dataUrl: string, autoTool?: string) => void;
  onOpenRecentProject: (project: ProjectState) => void;
  onOpenExports: () => void;
  onOpenProjects: () => void;
  onOpenCollage: () => void;
  onOpenBuildApk: () => void;
  onOpenSettings: () => void;
  onOpenCamera: () => void;
  recentProjects: ProjectState[];
  recentExports: ExportHistoryItem[];
  lang: Language;
  onToggleLang: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onSelectPhoto,
  onOpenRecentProject,
  onOpenExports,
  onOpenProjects,
  onOpenCollage,
  onOpenBuildApk,
  onOpenSettings,
  onOpenCamera,
  recentProjects,
  recentExports,
  lang,
  onToggleLang,
}) => {
  const t = useTranslation(lang);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pendingToolRef = useRef<string | undefined>(undefined);

  const handlePickFile = (tool?: string) => {
    pendingToolRef.current = tool;
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onSelectPhoto(reader.result, pendingToolRef.current);
      }
    };
    reader.readAsDataURL(file);
    // Reset input
    e.target.value = '';
  };

  const primaryActions = [
    {
      id: 'edit-photo',
      title: t.editPhoto,
      desc: 'Pro adjustment sliders & tone grading',
      icon: <ImageIcon className="w-6 h-6 text-cyan-400" />,
      color: 'from-cyan-500/20 to-blue-600/20 border-cyan-500/30',
      action: () => handlePickFile(),
    },
    {
      id: 'ai-editor',
      title: t.aiPhotoEditor,
      desc: 'Prompt-guided intelligent retouching',
      icon: <Sparkles className="w-6 h-6 text-purple-400" />,
      color: 'from-purple-500/20 to-indigo-600/20 border-purple-500/30',
      badge: 'GEMINI',
      action: () => handlePickFile('ai-assistant'),
    },
    {
      id: 'remove-bg',
      title: t.removeBackground,
      desc: 'Alpha cutout & custom backdrops',
      icon: <Scissors className="w-6 h-6 text-pink-400" />,
      color: 'from-pink-500/20 to-rose-600/20 border-pink-500/30',
      action: () => handlePickFile('remove-bg'),
    },
    {
      id: 'ai-eraser',
      title: t.aiEraser,
      desc: 'Cleanly wipe unwanted objects & marks',
      icon: <Eraser className="w-6 h-6 text-amber-400" />,
      color: 'from-amber-500/20 to-orange-600/20 border-amber-500/30',
      action: () => handlePickFile('ai-eraser'),
    },
  ];

  const quickTools = [
    {
      title: t.enhancePhoto,
      icon: <Flame className="w-5 h-5 text-emerald-400" />,
      action: () => handlePickFile('enhance'),
    },
    {
      title: t.portraitRetouch,
      icon: <UserCheck className="w-5 h-5 text-violet-400" />,
      action: () => handlePickFile('portrait'),
    },
    {
      title: t.filtersAndEffects,
      icon: <Palette className="w-5 h-5 text-blue-400" />,
      action: () => handlePickFile('filters'),
    },
    {
      title: t.collageMaker,
      icon: <LayoutGrid className="w-5 h-5 text-teal-400" />,
      action: onOpenCollage,
    },
    {
      title: t.photoToArt,
      icon: <Paintbrush className="w-5 h-5 text-fuchsia-400" />,
      action: () => handlePickFile('style-transfer'),
    },
    {
      title: t.addText,
      icon: <Type className="w-5 h-5 text-yellow-400" />,
      action: () => handlePickFile('text'),
    },
  ];

  return (
    <div className="min-h-screen bg-[#0b0d14] text-slate-100 pb-20 select-none">
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* Top Mobile App Bar */}
      <div className="sticky top-0 z-30 bg-[#0e121e]/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-purple-600 to-cyan-400 p-[1.5px] shadow-[0_0_20px_rgba(139,92,246,0.3)]">
            <div className="w-full h-full bg-[#0b0d14] rounded-[14px] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-purple-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-tight text-white">
                PIXORA <span className="text-cyan-400 font-black">AI</span>
              </span>
              <span className="text-[10px] bg-purple-500/20 text-purple-300 font-bold px-1.5 py-0.2 rounded border border-purple-500/30">
                PRO
              </span>
            </div>
            <p className="text-[10px] text-slate-400 -mt-0.5 font-medium">
              Mobile Photo Studio
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Language Toggle (EN / HI) */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1 bg-slate-900 border border-slate-800 hover:border-slate-700 px-2.5 py-1.5 rounded-xl text-xs font-semibold text-slate-300 transition-colors"
            title="Toggle English / हिंदी"
          >
            <Languages className="w-3.5 h-3.5 text-purple-400" />
            <span>{lang === 'en' ? 'हिन्दी' : 'EN'}</span>
          </button>

          {/* Settings button */}
          <button
            onClick={onOpenSettings}
            className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex items-center justify-center text-slate-300 transition-colors"
            title={t.settings}
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-4 space-y-6 max-w-lg mx-auto">
        {/* Android Import & Camera Hero Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-purple-950/60 via-[#131728] to-slate-950 border border-purple-500/25 p-5 shadow-xl">
          <div className="relative z-10 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-bold text-cyan-400 tracking-wider uppercase">
                  ANDROID STUDIO WORKFLOW
                </span>
                <h2 className="text-xl font-extrabold text-white mt-0.5">
                  Start Your Creation
                </h2>
                <p className="text-xs text-slate-300 mt-1 max-w-xs leading-relaxed">
                  Import high-res photos or snap directly from your camera with real GPU color grading.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                onClick={() => handlePickFile()}
                className="py-3 px-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/25 transition-all active:scale-[0.98]"
              >
                <ImageIcon className="w-4 h-4 text-purple-200" />
                <span>{t.importFromGallery}</span>
              </button>

              <button
                onClick={onOpenCamera}
                className="py-3 px-3 rounded-2xl bg-slate-800/90 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                <Camera className="w-4 h-4 text-cyan-400" />
                <span>{t.takePhoto}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Primary Action Cards Grid (4 Top Actions) */}
        <div>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 px-1">
            Featured Tools
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {primaryActions.map((item) => (
              <button
                key={item.id}
                onClick={item.action}
                className={`p-4 rounded-2xl bg-gradient-to-br ${item.color} border text-left flex flex-col justify-between h-32 transition-all hover:scale-[1.02] active:scale-[0.98] shadow-md`}
              >
                <div className="flex items-center justify-between w-full">
                  <div className="w-10 h-10 rounded-xl bg-slate-900/80 flex items-center justify-center border border-slate-800">
                    {item.icon}
                  </div>
                  {item.badge && (
                    <span className="text-[9px] font-mono font-extrabold bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded border border-purple-500/30">
                      {item.badge}
                    </span>
                  )}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-white">{item.title}</h4>
                  <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                    {item.desc}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Quick Tools Scroll Bar */}
        <div>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 px-1">
            Quick Studio Tools
          </h3>
          <div className="grid grid-cols-3 gap-2.5">
            {quickTools.map((tool, i) => (
              <button
                key={i}
                onClick={tool.action}
                className="flex flex-col items-center justify-center p-3 rounded-2xl bg-[#121624] border border-slate-800 hover:border-slate-700 transition-all hover:bg-slate-850 active:scale-95 text-center group"
              >
                <div className="w-9 h-9 rounded-xl bg-slate-900/90 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                  {tool.icon}
                </div>
                <span className="text-[11px] font-semibold text-slate-200 line-clamp-1">
                  {tool.title}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* 1-Click Instant Sample Photos */}
        <div>
          <div className="flex items-center justify-between mb-3 px-1">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              {t.selectSample}
            </h3>
            <span className="text-[10px] text-purple-400 font-medium">Ready to test</span>
          </div>

          <div className="flex items-center gap-3 overflow-x-auto pb-2 -mx-1 px-1">
            {SAMPLE_IMAGES.map((sample) => (
              <button
                key={sample.id}
                onClick={() => onSelectPhoto(sample.url)}
                className="flex-shrink-0 group relative w-24 h-32 rounded-2xl overflow-hidden border border-slate-800 hover:border-purple-500 transition-all active:scale-95 shadow-md"
              >
                <img
                  src={sample.url}
                  alt={sample.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2">
                  <span className="text-[10px] font-semibold text-white leading-tight">
                    {sample.title}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* APK Build Banner & 3D Studio Shortcut */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={onOpenBuildApk}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950/50 to-slate-900 border border-indigo-500/30 flex items-center gap-3 text-left hover:border-indigo-500/60 transition-all active:scale-95"
          >
            <div className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center flex-shrink-0">
              <FolderDown className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white leading-tight">
                APK Packaging
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">
                Capacitor & Gradle
              </div>
            </div>
          </button>

          <button
            onClick={onOpenExports}
            className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 to-[#121624] border border-slate-800 flex items-center gap-3 text-left hover:border-slate-700 transition-all active:scale-95"
          >
            <div className="w-9 h-9 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center flex-shrink-0">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white leading-tight">
                {t.myExports}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">
                {recentExports.length} Saved photos
              </div>
            </div>
          </button>
        </div>

        {/* Recent Projects Section */}
        {recentProjects.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3 px-1">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-purple-400" />
                {t.recentProjects}
              </h3>
              <button
                onClick={onOpenProjects}
                className="text-xs text-purple-400 hover:text-purple-300 font-medium flex items-center"
              >
                <span>View all</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {recentProjects.slice(0, 4).map((p) => (
                <button
                  key={p.id}
                  onClick={() => onOpenRecentProject(p)}
                  className="rounded-2xl bg-[#121624] border border-slate-800 hover:border-slate-700 overflow-hidden text-left transition-all active:scale-98 group"
                >
                  <div className="w-full h-28 bg-slate-900 relative overflow-hidden">
                    <img
                      src={p.thumbnailUrl || p.originalImage}
                      alt={p.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <span className="absolute bottom-1 right-1 bg-black/70 text-[9px] font-mono px-1.5 py-0.5 rounded text-slate-300">
                      {p.activeFilter || 'Custom'}
                    </span>
                  </div>
                  <div className="p-2.5">
                    <h5 className="font-semibold text-xs text-white truncate">
                      {p.name}
                    </h5>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      {new Date(p.updatedAt).toLocaleDateString()}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
