import React, { useState, useEffect } from 'react';
import { ProjectState, Language } from '../types';
import { getAllProjects, deleteProject } from '../utils/projectStorage';
import { ArrowLeft, Clock, Trash2, FolderOpen, Image as ImageIcon } from 'lucide-react';
import { useTranslation } from '../utils/translations';

interface ProjectsListScreenProps {
  onBack: () => void;
  onOpenProject: (project: ProjectState) => void;
  lang: Language;
}

export const ProjectsListScreen: React.FC<ProjectsListScreenProps> = ({
  onBack,
  onOpenProject,
  lang,
}) => {
  const t = useTranslation(lang);
  const [projects, setProjects] = useState<ProjectState[]>([]);

  useEffect(() => {
    setProjects(getAllProjects());
  }, []);

  const handleDelete = (id: string) => {
    deleteProject(id);
    setProjects((prev) => prev.filter((p) => p.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#0b0d14] text-slate-100 flex flex-col justify-between select-none">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-[#0e121e]/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Home</span>
        </button>

        <h3 className="font-extrabold text-sm text-white">{t.recentProjects}</h3>
        <span className="text-xs font-mono text-purple-400">{projects.length} saved</span>
      </div>

      {/* Content */}
      <div className="p-4 max-w-xl mx-auto w-full flex-1">
        {projects.length === 0 ? (
          <div className="text-center py-20 text-slate-500 space-y-3">
            <Clock className="w-12 h-12 text-slate-700 mx-auto" />
            <p className="text-xs">{t.emptyProjects}</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {projects.map((p) => (
              <div
                key={p.id}
                className="bg-[#121624] border border-slate-800 rounded-2xl overflow-hidden flex flex-col group"
              >
                <div
                  onClick={() => onOpenProject(p)}
                  className="aspect-square bg-slate-900 relative cursor-pointer"
                >
                  <img
                    src={p.thumbnailUrl || p.originalImage}
                    alt={p.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <span className="absolute bottom-1.5 right-1.5 bg-black/70 text-[9px] font-mono px-1.5 py-0.5 rounded text-white">
                    {p.activeFilter || 'Adjusted'}
                  </span>
                </div>

                <div className="p-2.5 flex items-center justify-between">
                  <div className="truncate mr-2">
                    <span className="text-xs font-semibold text-white block truncate">
                      {p.name}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(p.updatedAt).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onOpenProject(p)}
                      className="p-1.5 rounded-lg bg-purple-600/20 text-purple-300 hover:bg-purple-600 hover:text-white transition-colors"
                      title="Open Project"
                    >
                      <FolderOpen className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(p.id)}
                      className="p-1.5 rounded-lg bg-rose-950/40 text-rose-400 hover:bg-rose-900 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
