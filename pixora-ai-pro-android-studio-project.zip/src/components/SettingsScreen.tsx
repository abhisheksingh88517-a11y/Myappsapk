import React from 'react';
import {
  ArrowLeft,
  ShieldCheck,
  Languages,
  Crown,
  Smartphone,
  Lock,
  Cpu,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { Language } from '../types';
import { useTranslation } from '../utils/translations';
import { ANDROID_CONFIG } from '../utils/androidPackaging';

interface SettingsScreenProps {
  onBack: () => void;
  lang: Language;
  onToggleLang: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  onBack,
  lang,
  onToggleLang,
}) => {
  const t = useTranslation(lang);

  return (
    <div className="min-h-screen bg-[#0b0d14] text-slate-100 flex flex-col justify-between select-none">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-[#0e121e]/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Home</span>
        </button>

        <h3 className="font-extrabold text-sm text-white">{t.settings}</h3>
        <div className="w-10" />
      </div>

      {/* Settings list */}
      <div className="p-4 space-y-4 max-w-md mx-auto w-full flex-1">
        {/* Pro Status Card */}
        <div className="p-4 rounded-3xl bg-gradient-to-br from-purple-950/70 via-[#131728] to-slate-900 border border-purple-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
              <Crown className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-sm text-white">PIXORA PRO EDITION</span>
                <span className="text-[10px] bg-purple-500/20 text-purple-300 font-bold px-1.5 py-0.2 rounded border border-purple-500/30">
                  ACTIVE
                </span>
              </div>
              <p className="text-[11px] text-slate-400">All features unlocked</p>
            </div>
          </div>
        </div>

        {/* Preferences Section */}
        <div className="rounded-3xl bg-[#0e121e] border border-slate-800 overflow-hidden divide-y divide-slate-800">
          {/* Language Toggle */}
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Languages className="w-5 h-5 text-purple-400" />
              <div>
                <span className="text-xs font-bold text-white block">
                  Language / भाषा
                </span>
                <span className="text-[11px] text-slate-400">
                  {lang === 'en' ? 'English (Current)' : 'हिन्दी (Current)'}
                </span>
              </div>
            </div>

            <button
              onClick={onToggleLang}
              className="px-3 py-1.5 rounded-xl bg-purple-600 text-white font-semibold text-xs transition-colors"
            >
              {lang === 'en' ? 'Switch to हिन्दी' : 'Switch to English'}
            </button>
          </div>

          {/* Android Target Platform */}
          <div className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Smartphone className="w-5 h-5 text-cyan-400" />
              <div>
                <span className="text-xs font-bold text-white block">
                  Application Target
                </span>
                <span className="text-[11px] text-slate-400">
                  Android APK / Capacitor 34
                </span>
              </div>
            </div>
            <span className="text-xs font-mono text-slate-400">
              v{ANDROID_CONFIG.versionName}
            </span>
          </div>
        </div>

        {/* Security & Privacy Notice Card */}
        <div className="rounded-3xl bg-[#0e121e] border border-slate-800 p-4 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
            <ShieldCheck className="w-4 h-4" />
            <span>Privacy & Photo Security Disclosures</span>
          </div>

          <div className="space-y-2 text-xs text-slate-400 leading-relaxed">
            <p>
              • <strong>On-Device Photo Processing:</strong> All exposure, color grading, filters, and geometry adjustments execute 100% locally on your browser/device hardware using WebGL and HTML5 2D Canvas.
            </p>
            <p>
              • <strong>No Hidden Remote Uploads:</strong> Photos are never automatically sent to external servers. External AI generation (Gemini) is only invoked when you explicitly click AI actions.
            </p>
            <p>
              • <strong>Minimal Permissions:</strong> Only standard media read and camera capture permissions are requested for photo imports.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
