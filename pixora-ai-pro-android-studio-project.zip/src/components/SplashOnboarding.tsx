import React, { useState, useEffect } from 'react';
import { Sparkles, Sliders, Wand2, Layers, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Language } from '../types';
import { useTranslation } from '../utils/translations';

interface SplashOnboardingProps {
  onComplete: () => void;
  lang: Language;
}

export const SplashOnboarding: React.FC<SplashOnboardingProps> = ({ onComplete, lang }) => {
  const t = useTranslation(lang);
  const [step, setStep] = useState<'splash' | 'onboarding'>('splash');
  const [slide, setSlide] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setStep('onboarding');
    }, 1800);
    return () => clearTimeout(timer);
  }, []);

  const slides = [
    {
      icon: <Sliders className="w-12 h-12 text-cyan-400" />,
      title: 'Studio Grade Adjustments',
      titleHi: 'स्टूडियो ग्रेड एडजस्टमेंट्स',
      desc: 'Complete control over 18+ parameters: Exposure, Highlights, Shadows, Whites, Blacks, Vignette, and Film Grain.',
      descHi: 'एक्सपोज़र, हाइलाइट्स, शैडोज़, विगनेट और फिल्म ग्रेन पर पूरा कंट्रोल।',
      gradient: 'from-cyan-500/20 to-blue-600/20',
      badge: 'PRO ENGINE',
    },
    {
      icon: <Wand2 className="w-12 h-12 text-purple-400" />,
      title: 'Real AI Image Magic',
      titleHi: 'असली AI फोटो मैजिक',
      desc: 'Precision AI Background Remover, Gemini backdrop generation, AI Object Eraser, and natural language AI editing assistant.',
      descHi: 'AI बैकग्राउंड रिमूवर, ऑब्जेक्ट इरेज़र, और जेमिनी AI असिस्टेंट।',
      gradient: 'from-purple-500/20 to-pink-600/20',
      badge: 'GEMINI 3.8 POWERED',
    },
    {
      icon: <Layers className="w-12 h-12 text-amber-400" />,
      title: '3D Studio & Android Ready',
      titleHi: '3D स्टूडियो और एंड्रॉइड रेडी',
      desc: 'Inspect in interactive Three.js 3D light stage, create collages, and build native Android APK packages ready for installation.',
      descHi: '3D स्टूडियो में फोटो देखें, कोलाज बनाएं और तुरंत APK पैकेज तैयार करें।',
      gradient: 'from-amber-500/20 to-orange-600/20',
      badge: 'CAPACITOR & GRADLE',
    },
  ];

  if (step === 'splash') {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#0b0d14] text-white p-6 relative overflow-hidden">
        {/* Subtle radial glow background */}
        <div className="absolute w-96 h-96 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -bottom-10" />

        {/* Animated Brand Emblem */}
        <div className="relative mb-6">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-400 p-[2px] shadow-[0_0_40px_rgba(139,92,246,0.45)]">
            <div className="w-full h-full bg-[#0e121e] rounded-[22px] flex items-center justify-center">
              <Sparkles className="w-12 h-12 text-transparent bg-clip-text bg-gradient-to-r from-purple-300 via-white to-cyan-300 animate-pulse" />
            </div>
          </div>
          <div className="absolute -top-1 -right-1 bg-cyan-400 text-[#0b0d14] text-[10px] font-extrabold px-1.5 py-0.5 rounded-full uppercase tracking-wider">
            AI PRO
          </div>
        </div>

        <h1 className="text-3xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
          {t.appName}
        </h1>
        <p className="text-sm text-purple-300/80 mt-1 font-medium tracking-wide">
          {t.tagline}
        </p>

        <div className="mt-8 flex items-center gap-2 text-xs text-slate-500">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>Mobile GPU Processing Engine Ready</span>
        </div>
      </div>
    );
  }

  const current = slides[slide];

  return (
    <div className="flex flex-col justify-between min-h-screen bg-[#0b0d14] text-white p-6 max-w-md mx-auto relative select-none">
      {/* Top Bar with Skip */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-400 flex items-center justify-center font-bold text-sm">
            P
          </div>
          <span className="font-bold text-sm tracking-wide">PIXORA AI</span>
        </div>
        <button
          onClick={onComplete}
          className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg border border-slate-800 hover:border-slate-700 transition-colors"
        >
          Skip
        </button>
      </div>

      {/* Main Slide Card */}
      <div className="my-auto py-8 text-center flex flex-col items-center">
        <div
          className={`w-32 h-32 rounded-3xl bg-gradient-to-br ${current.gradient} border border-slate-700/60 flex items-center justify-center mb-8 shadow-2xl relative`}
        >
          {current.icon}
          <span className="absolute -bottom-3 bg-purple-600/90 text-white text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border border-purple-400/40">
            {current.badge}
          </span>
        </div>

        <h2 className="text-2xl font-bold tracking-tight text-white mb-3">
          {lang === 'hi' ? current.titleHi : current.title}
        </h2>
        <p className="text-sm text-slate-400 leading-relaxed max-w-xs">
          {lang === 'hi' ? current.descHi : current.desc}
        </p>

        {/* Dots */}
        <div className="flex items-center gap-2 mt-8">
          {slides.map((_, i) => (
            <div
              key={i}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                i === slide ? 'w-6 bg-purple-500' : 'w-2 bg-slate-700'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="space-y-4 pb-4">
        {slide < slides.length - 1 ? (
          <button
            onClick={() => setSlide(slide + 1)}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-all active:scale-[0.98]"
          >
            <span>Next</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={onComplete}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-all active:scale-[0.98]"
          >
            <span>Start Editing Now</span>
            <CheckCircle2 className="w-4 h-4" />
          </button>
        )}

        <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Local on-device processing. Photos stay private.</span>
        </div>
      </div>
    </div>
  );
};
