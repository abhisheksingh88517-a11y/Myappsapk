import React, { useState } from 'react';
import { TextLayer, StickerLayer } from '../types';
import { Plus, Trash2, Type, Smile, X, Palette, Bold, Italic } from 'lucide-react';

interface TextStickerEditorProps {
  isOpen: boolean;
  onClose: () => void;
  textLayers: TextLayer[];
  stickerLayers: StickerLayer[];
  onAddTextLayer: (layer: TextLayer) => void;
  onUpdateTextLayer: (layer: TextLayer) => void;
  onDeleteTextLayer: (id: string) => void;
  onAddStickerLayer: (sticker: StickerLayer) => void;
  onDeleteStickerLayer: (id: string) => void;
}

const FONTS = [
  'Plus Jakarta Sans',
  'sans-serif',
  'serif',
  'monospace',
  'cursive',
  'fantasy',
];

const EMOJI_STICKERS = [
  '🔥', '✨', '📸', '⚡', '🖤', '🌸', '👑', '💫', '💎', '🚀',
  '💯', '🎨', '🌟', '🕶️', '🎬', '☕', '🎉', '🏖️', '❤️', '🦋',
];

export const TextStickerEditor: React.FC<TextStickerEditorProps> = ({
  isOpen,
  onClose,
  textLayers,
  stickerLayers,
  onAddTextLayer,
  onUpdateTextLayer,
  onDeleteTextLayer,
  onAddStickerLayer,
  onDeleteStickerLayer,
}) => {
  const [activeTab, setActiveTab] = useState<'text' | 'stickers'>('text');
  const [selectedTextId, setSelectedTextId] = useState<string | null>(
    textLayers[0]?.id || null
  );

  if (!isOpen) return null;

  const selectedText = textLayers.find((t) => t.id === selectedTextId);

  const handleCreateNewText = () => {
    const newLayer: TextLayer = {
      id: 'text-' + Date.now(),
      text: 'PIXORA PRO',
      x: 0.5,
      y: 0.5,
      fontSize: 32,
      fontFamily: 'Plus Jakarta Sans',
      color: '#ffffff',
      outlineColor: '#8b5cf6',
      outlineWidth: 2,
      rotation: 0,
      opacity: 1,
      align: 'center',
      bold: true,
      italic: false,
    };
    onAddTextLayer(newLayer);
    setSelectedTextId(newLayer.id);
  };

  const handleAddEmojiSticker = (emoji: string) => {
    const newSticker: StickerLayer = {
      id: 'sticker-' + Date.now(),
      src: emoji,
      x: 0.5,
      y: 0.5,
      width: 48,
      height: 48,
      rotation: 0,
      opacity: 1,
      isEmoji: true,
    };
    onAddStickerLayer(newSticker);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 select-none">
      <div className="w-full sm:max-w-lg bg-[#0e121e] border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Type className="w-5 h-5 text-purple-400" />
            <h3 className="font-extrabold text-base text-white">Text & Stickers</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-slate-800">
          <button
            onClick={() => setActiveTab('text')}
            className={`flex-1 py-3 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'text'
                ? 'border-purple-500 text-purple-400 bg-purple-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Typography Layers ({textLayers.length})
          </button>
          <button
            onClick={() => setActiveTab('stickers')}
            className={`flex-1 py-3 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'stickers'
                ? 'border-purple-500 text-purple-400 bg-purple-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Stickers & Badges ({stickerLayers.length})
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-5 overflow-y-auto space-y-4">
          {activeTab === 'text' && (
            <div className="space-y-4">
              <button
                onClick={handleCreateNewText}
                className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Text Layer</span>
              </button>

              {/* Layer selector chips */}
              {textLayers.length > 0 && (
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {textLayers.map((tl, i) => (
                    <button
                      key={tl.id}
                      onClick={() => setSelectedTextId(tl.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border flex items-center gap-1.5 ${
                        selectedTextId === tl.id
                          ? 'bg-purple-600/30 text-purple-300 border-purple-500'
                          : 'bg-slate-900 text-slate-400 border-slate-800'
                      }`}
                    >
                      <span>Layer {i + 1}:</span>
                      <span className="truncate max-w-[80px]">{tl.text}</span>
                    </button>
                  ))}
                </div>
              )}

              {/* Edit Selected Text Layer */}
              {selectedText ? (
                <div className="space-y-3 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300">Edit Text Content</span>
                    <button
                      onClick={() => onDeleteTextLayer(selectedText.id)}
                      className="text-rose-400 hover:text-rose-300 text-xs flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>

                  <input
                    type="text"
                    value={selectedText.text}
                    onChange={(e) =>
                      onUpdateTextLayer({ ...selectedText, text: e.target.value })
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  />

                  {/* Font & Size */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[11px] text-slate-400 block mb-1">Font Family</span>
                      <select
                        value={selectedText.fontFamily}
                        onChange={(e) =>
                          onUpdateTextLayer({ ...selectedText, fontFamily: e.target.value })
                        }
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-xs text-slate-200"
                      >
                        {FONTS.map((f) => (
                          <option key={f} value={f}>
                            {f}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <span className="text-[11px] text-slate-400 block mb-1">
                        Size: {selectedText.fontSize}px
                      </span>
                      <input
                        type="range"
                        min={14}
                        max={72}
                        value={selectedText.fontSize}
                        onChange={(e) =>
                          onUpdateTextLayer({
                            ...selectedText,
                            fontSize: Number(e.target.value),
                          })
                        }
                        className="w-full mt-2"
                      />
                    </div>
                  </div>

                  {/* Colors */}
                  <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400">Color:</span>
                      <input
                        type="color"
                        value={selectedText.color}
                        onChange={(e) =>
                          onUpdateTextLayer({ ...selectedText, color: e.target.value })
                        }
                        className="w-7 h-7 rounded border border-slate-700 bg-transparent cursor-pointer"
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400">Glow Outline:</span>
                      <input
                        type="color"
                        value={selectedText.outlineColor || '#8b5cf6'}
                        onChange={(e) =>
                          onUpdateTextLayer({ ...selectedText, outlineColor: e.target.value })
                        }
                        className="w-7 h-7 rounded border border-slate-700 bg-transparent cursor-pointer"
                      />
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() =>
                          onUpdateTextLayer({
                            ...selectedText,
                            bold: !selectedText.bold,
                          })
                        }
                        className={`p-1.5 rounded-lg border ${
                          selectedText.bold
                            ? 'bg-purple-600/30 text-purple-300 border-purple-500'
                            : 'bg-slate-950 text-slate-400 border-slate-800'
                        }`}
                      >
                        <Bold className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() =>
                          onUpdateTextLayer({
                            ...selectedText,
                            italic: !selectedText.italic,
                          })
                        }
                        className={`p-1.5 rounded-lg border ${
                          selectedText.italic
                            ? 'bg-purple-600/30 text-purple-300 border-purple-500'
                            : 'bg-slate-950 text-slate-400 border-slate-800'
                        }`}
                      >
                        <Italic className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-slate-500 text-center py-4">
                  No text layers yet. Click "Add New Text Layer" to begin.
                </p>
              )}
            </div>
          )}

          {activeTab === 'stickers' && (
            <div className="space-y-4">
              <span className="text-xs font-semibold text-slate-400 block">
                Tap to place emoji sticker on photo:
              </span>

              <div className="grid grid-cols-5 gap-3">
                {EMOJI_STICKERS.map((em, i) => (
                  <button
                    key={i}
                    onClick={() => handleAddEmojiSticker(em)}
                    className="h-12 rounded-2xl bg-slate-900 border border-slate-800 hover:border-purple-500 hover:scale-110 active:scale-95 text-2xl flex items-center justify-center transition-all shadow"
                  >
                    {em}
                  </button>
                ))}
              </div>

              {stickerLayers.length > 0 && (
                <div className="pt-4 border-t border-slate-800 space-y-2">
                  <span className="text-xs font-semibold text-slate-400 block">
                    Active Stickers ({stickerLayers.length})
                  </span>
                  <div className="flex items-center gap-2 overflow-x-auto">
                    {stickerLayers.map((st) => (
                      <div
                        key={st.id}
                        className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-2 rounded-xl"
                      >
                        <span className="text-xl">{st.src}</span>
                        <button
                          onClick={() => onDeleteStickerLayer(st.id)}
                          className="text-rose-400 hover:text-rose-300"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
