import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Camera, Rotate3d, Sun, Sparkles, Layers, Eye, Download, X } from 'lucide-react';

interface ThreePhotoStudioProps {
  photoCanvas: HTMLCanvasElement | null;
  photoUrl?: string;
  onClose: () => void;
}

// Pre-allocated scratch helpers at module scope to avoid GC in animation loop
const _scratchVec3 = new THREE.Vector3();
const _scratchEuler = new THREE.Euler();

export const ThreePhotoStudio: React.FC<ThreePhotoStudioProps> = ({
  photoCanvas,
  photoUrl,
  onClose,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [lightPreset, setLightPreset] = useState<'gallery' | 'dramatic' | 'neon' | 'sunset'>('gallery');
  const [tiltX, setTiltX] = useState(0);
  const [tiltY, setTiltY] = useState(0);
  const [exploded, setExploded] = useState(0);
  const [autoRotate, setAutoRotate] = useState(true);

  // References to interactive 3D elements
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const photoMeshGroupRef = useRef<THREE.Group | null>(null);
  const glassMeshRef = useRef<THREE.Mesh | null>(null);
  const frameMeshRef = useRef<THREE.Mesh | null>(null);
  const photoTextureRef = useRef<THREE.CanvasTexture | THREE.Texture | null>(null);
  const keyLightRef = useRef<THREE.DirectionalLight | null>(null);
  const rimLightRef = useRef<THREE.PointLight | null>(null);
  const hemiLightRef = useRef<THREE.HemisphereLight | null>(null);

  // Pointer drag state for smooth orbit/tilt
  const isDraggingRef = useRef(false);
  const previousPointerRef = useRef({ x: 0, y: 0 });
  const targetRotationRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // Scene setup with atmospheric fog
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0d14);
    scene.fog = new THREE.FogExp2(0x0b0d14, 0.04);
    sceneRef.current = scene;

    // Camera setup
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 1.4, 4.2);
    camera.lookAt(0, 0.9, 0);
    cameraRef.current = camera;

    // Renderer setup with PBR ACESFilmic tone mapping
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // Studio Environment map via PMREMGenerator & RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Studio 3-point Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x1e1b4b, 0.8);
    scene.add(hemiLight);
    hemiLightRef.current = hemiLight;

    const keyLight = new THREE.DirectionalLight(0xfff7ed, 2.8);
    keyLight.position.set(3, 4, 3);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);
    keyLightRef.current = keyLight;

    const rimLight = new THREE.PointLight(0xa855f7, 2.2, 10);
    rimLight.position.set(-3, 2, -2);
    scene.add(rimLight);
    rimLightRef.current = rimLight;

    // Composite 3-12 Part Procedural Studio Rig (THREE.Group)
    const studioRigGroup = new THREE.Group();
    studioRigGroup.position.set(0, 0, 0);

    // Part 1: Circular Studio Pedestal Floor Base
    const pedestalGeo = new THREE.CylinderGeometry(2.4, 2.6, 0.12, 48);
    const pedestalMat = new THREE.MeshStandardMaterial({
      color: 0x111422,
      roughness: 0.25,
      metalness: 0.85,
    });
    const pedestalMesh = new THREE.Mesh(pedestalGeo, pedestalMat);
    pedestalMesh.position.y = 0.06;
    pedestalMesh.receiveShadow = !isSoftwareGl;
    studioRigGroup.add(pedestalMesh);

    // Part 2: Soft radial contact shadow plane
    const shadowGeo = new THREE.PlaneGeometry(5.2, 5.2);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x030712,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.01;
    studioRigGroup.add(shadowMesh);

    // Part 3: Brushed Steel Tripod Center Stem
    const stemGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.2, 16);
    const stemMat = new THREE.MeshStandardMaterial({
      color: 0x64748b,
      metalness: 0.95,
      roughness: 0.18,
    });
    const stemMesh = new THREE.Mesh(stemGeo, stemMat);
    stemMesh.position.y = 0.7;
    stemMesh.castShadow = !isSoftwareGl;
    studioRigGroup.add(stemMesh);

    // Part 4: Anodized tripod legs (3 legs spaced radially)
    for (let i = 0; i < 3; i++) {
      const angle = (i * Math.PI * 2) / 3;
      const legGeo = new THREE.CylinderGeometry(0.025, 0.025, 0.8, 12);
      const legMat = new THREE.MeshStandardMaterial({
        color: 0x334155,
        metalness: 0.9,
        roughness: 0.25,
      });
      const leg = new THREE.Mesh(legGeo, legMat);
      leg.position.set(Math.cos(angle) * 0.25, 0.35, Math.sin(angle) * 0.25);
      leg.rotation.z = Math.cos(angle) * 0.35;
      leg.rotation.x = -Math.sin(angle) * 0.35;
      studioRigGroup.add(leg);
    }

    // Part 5: Gimbal Mount Ball
    const gimbalGeo = new THREE.SphereGeometry(0.08, 24, 24);
    const gimbalMat = new THREE.MeshStandardMaterial({
      color: 0x9333ea,
      metalness: 0.9,
      roughness: 0.2,
    });
    const gimbal = new THREE.Mesh(gimbalGeo, gimbalMat);
    gimbal.position.y = 1.32;
    studioRigGroup.add(gimbal);

    // Part 6 & 7: Hero Photo Frame Group (Photo Board, Frame, Glass)
    const photoGroup = new THREE.Group();
    photoGroup.position.set(0, 1.45, 0);
    photoMeshGroupRef.current = photoGroup;

    // Procedural texture for photo
    let texture: THREE.Texture;
    if (photoCanvas) {
      texture = new THREE.CanvasTexture(photoCanvas);
    } else {
      // Default procedural dark studio canvas
      const cvs = document.createElement('canvas');
      cvs.width = 512;
      cvs.height = 512;
      const ctx = cvs.getContext('2d')!;
      const grad = ctx.createLinearGradient(0, 0, 512, 512);
      grad.addColorStop(0, '#8b5cf6');
      grad.addColorStop(1, '#06b6d4');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 512, 512);
      texture = new THREE.CanvasTexture(cvs);
    }
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = renderer.capabilities.getMaxAnisotropy();
    photoTextureRef.current = texture;

    // Aspect ratio calculation
    const aspect = photoCanvas ? photoCanvas.width / photoCanvas.height : 1;
    const photoWidth = aspect >= 1 ? 1.6 : 1.6 * aspect;
    const photoHeight = aspect >= 1 ? 1.6 / aspect : 1.6;

    // Photo Board Plane
    const photoPlaneGeo = new THREE.PlaneGeometry(photoWidth, photoHeight);
    const photoPlaneMat = new THREE.MeshStandardMaterial({
      map: texture,
      roughness: 0.3,
      metalness: 0.05,
    });
    const photoMesh = new THREE.Mesh(photoPlaneGeo, photoPlaneMat);
    photoMesh.castShadow = !isSoftwareGl;
    photoGroup.add(photoMesh);

    // Part 8: Titanium Beveled Frame Border
    const frameGeo = new THREE.BoxGeometry(photoWidth + 0.08, photoHeight + 0.08, 0.04);
    const frameMat = new THREE.MeshStandardMaterial({
      color: 0x1e1b4b,
      metalness: 0.95,
      roughness: 0.15,
    });
    const frameMesh = new THREE.Mesh(frameGeo, frameMat);
    frameMesh.position.z = -0.025;
    frameMesh.castShadow = !isSoftwareGl;
    photoGroup.add(frameMesh);
    frameMeshRef.current = frameMesh;

    // Part 9: Anti-Reflective Optical Glass Cover
    const glassGeo = new THREE.PlaneGeometry(photoWidth + 0.04, photoHeight + 0.04);
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: isSoftwareGl ? 0.2 : 0.35,
      roughness: 0.05,
      metalness: 0.1,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1,
      transmission: isSoftwareGl ? 0 : 0.85,
      ior: 1.52,
      depthWrite: false,
    });
    const glassMesh = new THREE.Mesh(glassGeo, glassMat);
    glassMesh.position.z = 0.02;
    photoGroup.add(glassMesh);
    glassMeshRef.current = glassMesh;

    // Part 10 & 11: Studio Softbox Light Panels (decorative studio models)
    const softboxGeo = new THREE.BoxGeometry(0.35, 0.6, 0.15);
    const softboxMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.7 });
    const softboxDiffMat = new THREE.MeshBasicMaterial({ color: 0xfffbeb });

    const leftSoftbox = new THREE.Group();
    const sbMesh1 = new THREE.Mesh(softboxGeo, softboxMat);
    const sbDiff1 = new THREE.Mesh(new THREE.PlaneGeometry(0.33, 0.58), softboxDiffMat);
    sbDiff1.position.z = 0.076;
    leftSoftbox.add(sbMesh1, sbDiff1);
    leftSoftbox.position.set(-1.8, 1.8, 1.2);
    leftSoftbox.lookAt(0, 1.45, 0);
    studioRigGroup.add(leftSoftbox);

    const rightSoftbox = new THREE.Group();
    const sbMesh2 = new THREE.Mesh(softboxGeo, softboxMat);
    const sbDiff2 = new THREE.Mesh(new THREE.PlaneGeometry(0.33, 0.58), softboxDiffMat);
    sbDiff2.position.z = 0.076;
    rightSoftbox.add(sbMesh2, sbDiff2);
    rightSoftbox.position.set(1.8, 1.9, 1.0);
    rightSoftbox.lookAt(0, 1.45, 0);
    studioRigGroup.add(rightSoftbox);

    scene.add(studioRigGroup);
    scene.add(photoGroup);

    // Animation & Render Loop
    let frameId = 0;
    const clock = new THREE.Clock();

    function renderLoop() {
      const delta = clock.getDelta();

      // Exponential damping for smooth turntable & user tilt
      if (photoMeshGroupRef.current) {
        if (autoRotate && !isDraggingRef.current) {
          targetRotationRef.current.y += delta * 0.45;
        }

        const curRot = photoMeshGroupRef.current.rotation;
        curRot.x = THREE.MathUtils.damp(curRot.x, targetRotationRef.current.x, 6, delta);
        curRot.y = THREE.MathUtils.damp(curRot.y, targetRotationRef.current.y, 6, delta);
      }

      // Smooth exploded layer separation
      if (glassMeshRef.current && frameMeshRef.current) {
        const targetGlassZ = 0.02 + (exploded / 100) * 0.35;
        const targetFrameZ = -0.025 - (exploded / 100) * 0.35;
        glassMeshRef.current.position.z = THREE.MathUtils.damp(
          glassMeshRef.current.position.z,
          targetGlassZ,
          8,
          delta
        );
        frameMeshRef.current.position.z = THREE.MathUtils.damp(
          frameMeshRef.current.position.z,
          targetFrameZ,
          8,
          delta
        );
      }

      renderer.render(scene, camera);
      frameId = requestAnimationFrame(renderLoop);
    }

    frameId = requestAnimationFrame(renderLoop);

    // Resize handler
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', handleResize);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
      texture.dispose();
    };
  }, [photoCanvas]);

  // Update lighting preset
  useEffect(() => {
    if (!keyLightRef.current || !rimLightRef.current || !hemiLightRef.current) return;

    if (lightPreset === 'gallery') {
      keyLightRef.current.color.setHex(0xfff7ed);
      keyLightRef.current.intensity = 2.8;
      rimLightRef.current.color.setHex(0xa855f7);
      rimLightRef.current.intensity = 1.8;
      hemiLightRef.current.color.setHex(0xdbeafe);
    } else if (lightPreset === 'dramatic') {
      keyLightRef.current.color.setHex(0xffffff);
      keyLightRef.current.intensity = 4.2;
      rimLightRef.current.color.setHex(0x38bdf8);
      rimLightRef.current.intensity = 3.0;
      hemiLightRef.current.color.setHex(0x0f172a);
    } else if (lightPreset === 'neon') {
      keyLightRef.current.color.setHex(0xec4899);
      keyLightRef.current.intensity = 3.5;
      rimLightRef.current.color.setHex(0x06b6d4);
      rimLightRef.current.intensity = 4.0;
      hemiLightRef.current.color.setHex(0x312e81);
    } else if (lightPreset === 'sunset') {
      keyLightRef.current.color.setHex(0xf97316);
      keyLightRef.current.intensity = 3.2;
      rimLightRef.current.color.setHex(0xf43f5e);
      rimLightRef.current.intensity = 2.4;
      hemiLightRef.current.color.setHex(0x7c2d12);
    }
  }, [lightPreset]);

  // Pointer drag controls for photo tilt
  const handlePointerDown = (e: React.PointerEvent) => {
    isDraggingRef.current = true;
    previousPointerRef.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - previousPointerRef.current.x;
    const dy = e.clientY - previousPointerRef.current.y;
    previousPointerRef.current = { x: e.clientX, y: e.clientY };

    targetRotationRef.current.y += dx * 0.008;
    targetRotationRef.current.x = Math.max(
      -0.6,
      Math.min(0.6, targetRotationRef.current.x + dy * 0.008)
    );
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
  };

  // Capture 3D render to PNG
  const handleCapture3DSnapshot = () => {
    if (!rendererRef.current || !sceneRef.current || !cameraRef.current) return;
    rendererRef.current.render(sceneRef.current, cameraRef.current);
    const dataUrl = rendererRef.current.domElement.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `pixora-3d-studio-${Date.now()}.png`;
    link.href = dataUrl;
    link.click();
  };

  return (
    <div
      className="relative w-full h-full bg-[#0b0d14] overflow-hidden select-none"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
    >
      {/* 3D WebGL Canvas container */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Header Badge */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none z-10">
        <div className="flex items-center gap-2 bg-[#121624]/90 border border-purple-500/30 px-3 py-1.5 rounded-full shadow-lg pointer-events-auto">
          <Rotate3d className="w-4 h-4 text-purple-400" />
          <span className="text-xs font-semibold tracking-wide text-slate-200">
            3D Studio Stage
          </span>
          <span className="text-[10px] bg-purple-500/20 text-purple-300 font-mono px-1.5 py-0.5 rounded">
            PBR View
          </span>
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={handleCapture3DSnapshot}
            className="flex items-center gap-1.5 bg-[#121624]/90 hover:bg-purple-600/30 border border-slate-700/60 hover:border-purple-500/50 text-slate-200 text-xs font-medium px-3 py-1.5 rounded-full shadow-lg transition-all"
            title="Export 3D Studio Render"
          >
            <Download className="w-3.5 h-3.5 text-purple-400" />
            <span>Snapshot</span>
          </button>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#121624]/90 hover:bg-red-500/30 border border-slate-700/60 flex items-center justify-center text-slate-300 hover:text-white transition-all shadow-lg"
            title="Exit 3D Studio"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Viewport Notice */}
      <div className="absolute top-16 left-1/2 -translate-x-1/2 bg-[#121624]/75 border border-slate-800 text-[11px] text-slate-400 px-3 py-1 rounded-full pointer-events-none">
        Drag anywhere to rotate & tilt photo in 3D studio light
      </div>

      {/* Collapsible Unified Bottom Control Dock */}
      <div
        className="absolute bottom-4 left-1/2 -translate-x-1/2 w-[94%] max-w-2xl bg-[#121624]/95 border border-purple-500/25 rounded-2xl shadow-2xl transition-transform duration-300 z-20 overflow-hidden"
        style={{
          transform: `translate(-50%, ${isCollapsed ? 'calc(100% - 32px)' : '0'})`,
        }}
      >
        {/* Collapse Handle Tab */}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="w-full h-8 flex items-center justify-center gap-2 bg-gradient-to-r from-purple-950/40 via-[#161b2e] to-purple-950/40 border-b border-slate-800 text-slate-300 hover:text-white text-xs font-medium cursor-pointer transition-colors"
        >
          <span>{isCollapsed ? '▴ Show Studio Dock' : '▾ Hide Controls (Cinema Mode)'}</span>
        </button>

        {/* Dock Controls */}
        <div className="p-4 space-y-3">
          {/* Studio Light Presets */}
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-amber-400" /> Lighting:
            </span>
            <div className="flex items-center gap-1.5 overflow-x-auto py-1">
              {(
                [
                  { id: 'gallery', label: 'Gallery Soft' },
                  { id: 'dramatic', label: 'Dramatic' },
                  { id: 'neon', label: 'Cyberpunk' },
                  { id: 'sunset', label: 'Sunset Amber' },
                ] as const
              ).map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => setLightPreset(preset.id)}
                  className={`text-xs px-2.5 py-1 rounded-lg border font-medium transition-all ${
                    lightPreset === preset.id
                      ? 'bg-purple-600 text-white border-purple-400 shadow-sm'
                      : 'bg-slate-800/60 text-slate-300 border-slate-700/50 hover:bg-slate-800'
                  }`}
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          {/* Sliders: Exploded Frame Separation & Turntable */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-800/80">
            {/* Exploded Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-300">
                <span className="flex items-center gap-1 text-slate-400">
                  <Layers className="w-3.5 h-3.5 text-cyan-400" /> Frame Separation
                </span>
                <span className="font-mono text-[11px] text-cyan-300">{exploded}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={exploded}
                onChange={(e) => setExploded(Number(e.target.value))}
                className="w-full"
              />
            </div>

            {/* Turntable Auto-Rotate Toggle */}
            <div className="flex items-center justify-between bg-slate-900/60 border border-slate-800 rounded-xl px-3 py-1.5">
              <span className="text-xs text-slate-300 flex items-center gap-1.5">
                <Rotate3d className="w-3.5 h-3.5 text-purple-400" />
                Turntable Spin
              </span>
              <button
                onClick={() => setAutoRotate(!autoRotate)}
                className={`text-xs font-semibold px-3 py-1 rounded-md transition-all ${
                  autoRotate
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                {autoRotate ? 'ON' : 'PAUSED'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
