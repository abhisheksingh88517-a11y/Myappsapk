export type ScreenType =
  | 'splash'
  | 'onboarding'
  | 'home'
  | 'editor'
  | 'collage'
  | 'projects'
  | 'exports'
  | 'build-apk'
  | 'settings'
  | 'three-studio';

export type Language = 'en' | 'hi';

export interface ImageAdjustments {
  brightness: number;     // -100 to 100
  exposure: number;       // -50 to 50
  contrast: number;       // -100 to 100
  saturation: number;     // -100 to 100
  vibrance: number;       // -100 to 100
  temperature: number;    // -100 to 100 (cool to warm)
  tint: number;           // -100 to 100 (green to magenta)
  highlights: number;     // -100 to 100
  shadows: number;        // -100 to 100
  whites: number;         // -100 to 100
  blacks: number;         // -100 to 100
  gamma: number;          // -50 to 50
  hue: number;            // -180 to 180
  sharpness: number;      // 0 to 100
  clarity: number;        // -50 to 50
  fade: number;           // 0 to 100
  vignette: number;       // 0 to 100
  grain: number;          // 0 to 100
  blur: number;           // 0 to 50
}

export interface GeometryTransform {
  rotation: number;        // -180 to 180 degrees (straighten)
  flipH: boolean;
  flipV: boolean;
  crop: {
    x: number;
    y: number;
    width: number;
    height: number;
  } | null;
  aspectRatio: string;     // 'original', '1:1', '4:5', '3:4', '9:16', '16:9', 'free'
}

export interface TextLayer {
  id: string;
  text: string;
  x: number;               // 0 to 1 relative
  y: number;               // 0 to 1 relative
  fontSize: number;        // 14 to 96
  fontFamily: string;
  color: string;
  backgroundColor?: string;
  outlineColor?: string;
  outlineWidth?: number;
  rotation: number;        // degrees
  opacity: number;         // 0 to 1
  align: 'left' | 'center' | 'right';
  bold: boolean;
  italic: boolean;
}

export interface StickerLayer {
  id: string;
  src: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  opacity: number;
  isEmoji?: boolean;
}

export interface FilterPreset {
  id: string;
  name: string;
  nameHi: string;
  category: 'Cinematic' | 'Portrait' | 'Vintage' | 'B&W' | 'Moody' | 'Warm' | 'Creative';
  intensity: number;      // 0 to 100
  thumbnailColor: string;
  adjustments: Partial<ImageAdjustments>;
}

export interface ProjectState {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  thumbnailUrl: string;
  originalImage: string;   // data URL
  currentAdjustments: ImageAdjustments;
  geometry: GeometryTransform;
  activeFilter: string;
  filterIntensity: number;
  textLayers: TextLayer[];
  stickerLayers: StickerLayer[];
  maskDataUrl?: string;    // mask for segmentation or eraser
  width: number;
  height: number;
}

export interface ExportHistoryItem {
  id: string;
  dataUrl: string;
  filename: string;
  format: 'jpeg' | 'png' | 'webp';
  width: number;
  height: number;
  fileSizeBytes: number;
  exportedAt: number;
}
