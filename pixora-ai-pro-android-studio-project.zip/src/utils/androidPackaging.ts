import JSZip from 'jszip';

export interface AndroidPackageManifest {
  appId: string;
  appName: string;
  versionName: string;
  versionCode: number;
  minSdkVersion: number;
  targetSdkVersion: number;
  compileSdkVersion: number;
}

export const ANDROID_CONFIG: AndroidPackageManifest = {
  appId: 'ai.pixora.photoeditor',
  appName: 'PIXORA AI Pro',
  versionName: '2.4.0',
  versionCode: 24,
  minSdkVersion: 24,
  targetSdkVersion: 34,
  compileSdkVersion: 34,
};

export async function generateAndroidProjectZip(): Promise<Blob> {
  const zip = new JSZip();

  // Root files
  zip.file(
    'capacitor.config.json',
    JSON.stringify(
      {
        appId: ANDROID_CONFIG.appId,
        appName: ANDROID_CONFIG.appName,
        webDir: 'dist',
        bundledWebRuntime: false,
        server: {
          androidScheme: 'https',
          cleartext: true,
        },
        android: {
          allowMixedContent: true,
          captureInput: true,
          webContentsDebuggingEnabled: false,
        },
      },
      null,
      2
    )
  );

  // README with clear build steps
  zip.file(
    'README_ANDROID_BUILD.md',
    `# PIXORA AI Pro — Android Native Build Guide

Package Name: \`${ANDROID_CONFIG.appId}\`
Version: \`${ANDROID_CONFIG.versionName}\` (Code ${ANDROID_CONFIG.versionCode})
Target SDK: ${ANDROID_CONFIG.targetSdkVersion} | Min SDK: ${ANDROID_CONFIG.minSdkVersion}

## Option 1: Build APK in Android Studio (Recommended)
1. Install Android Studio (Hedgehog or newer) with Android SDK 34 and JDK 17.
2. Open this folder in Android Studio as an Android project.
3. Wait for Gradle Sync to complete.
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The generated APK will be at:
   \`app/build/outputs/apk/debug/app-debug.apk\`
6. Transfer \`app-debug.apk\` to your Android phone and install!

## Option 2: Command Line Build (Terminal / CI)
\`\`\`bash
# 1. Ensure ANDROID_HOME is set in your environment
export ANDROID_HOME=$HOME/Android/Sdk

# 2. Build debug APK
chmod +x gradlew
./gradlew assembleDebug

# 3. Locate APK
ls -lh app/build/outputs/apk/debug/app-debug.apk
\`\`\`

## Option 3: Automated Free GitHub Actions APK Cloud Build
1. Push this repository to GitHub.
2. The included \`.github/workflows/build-apk.yml\` will automatically run Gradle on Ubuntu.
3. Once completed in ~2 minutes, go to GitHub **Actions > Build Android APK > Artifacts**.
4. Download the ready-to-install \`pixora-ai-pro-debug.apk\`!
`
  );

  // GitHub Actions CI build workflow
  zip.file(
    '.github/workflows/build-apk.yml',
    `name: Build Android APK
on: [push, workflow_dispatch]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'
      - name: Setup Android SDK
        uses: android-actions/setup-android@v3
      - name: Build Debug APK
        run: |
          chmod +x gradlew || true
          ./gradlew assembleDebug --stacktrace
      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: pixora-ai-pro-debug.apk
          path: app/build/outputs/apk/debug/app-debug.apk
`
  );

  // Android build.gradle (root)
  zip.file(
    'build.gradle',
    `// Top-level build file
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.2.2'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
`
  );

  // settings.gradle
  zip.file(
    'settings.gradle',
    `include ':app'
rootProject.name = "PixoraAI"
`
  );

  // app/build.gradle
  zip.file(
    'app/build.gradle',
    `plugins {
    id 'com.android.application'
}

android {
    namespace "${ANDROID_CONFIG.appId}"
    compileSdk ${ANDROID_CONFIG.compileSdkVersion}

    defaultConfig {
        applicationId "${ANDROID_CONFIG.appId}"
        minSdk ${ANDROID_CONFIG.minSdkVersion}
        targetSdk ${ANDROID_CONFIG.targetSdkVersion}
        versionCode ${ANDROID_CONFIG.versionCode}
        versionName "${ANDROID_CONFIG.versionName}"
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            applicationIdSuffix ".debug"
            debuggable true
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.activity:activity:1.8.2'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.core:core-splashscreen:1.0.1'
}
`
  );

  // app/src/main/AndroidManifest.xml
  zip.file(
    'app/src/main/AndroidManifest.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Permissions required for photo editing and camera capture -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />

    <uses-feature android:name="android.hardware.camera" android:required="false" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:hardwareAccelerated="true"
        android:theme="@style/Theme.PixoraAI">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:theme="@style/Theme.PixoraAI.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`
  );

  // app/src/main/java/ai/pixora/photoeditor/MainActivity.java
  zip.file(
    'app/src/main/java/ai/pixora/photoeditor/MainActivity.java',
    `package ai.pixora.photoeditor;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        // In local production this loads from android_asset or configured host
        webView.loadUrl("file:///android_asset/public/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
`
  );

  // app/src/main/res/values/strings.xml
  zip.file(
    'app/src/main/res/values/strings.xml',
    `<resources>
    <string name="app_name">PIXORA AI</string>
    <string name="title_activity_main">PIXORA AI Pro</string>
</resources>
`
  );

  // app/src/main/res/values/styles.xml
  zip.file(
    'app/src/main/res/values/styles.xml',
    `<resources>
    <style name="Theme.PixoraAI" parent="Theme.Material3.DayNight">
        <item name="colorPrimary">#8B5CF6</item>
        <item name="colorSecondary">#06B6D4</item>
        <item name="android:statusBarColor">#0B0D14</item>
        <item name="android:navigationBarColor">#0B0D14</item>
    </style>
    <style name="Theme.PixoraAI.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="windowNoTitle">true</item>
    </style>
</resources>
`
  );

  return await zip.generateAsync({ type: 'blob' });
}
