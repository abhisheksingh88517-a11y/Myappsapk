import { ImageAdjustments, GeometryTransform, FilterPreset } from '../types';

export const DEFAULT_ADJUSTMENTS: ImageAdjustments = {
  brightness: 0,
  exposure: 0,
  contrast: 0,
  saturation: 0,
  vibrance: 0,
  temperature: 0,
  tint: 0,
  highlights: 0,
  shadows: 0,
  whites: 0,
  blacks: 0,
  gamma: 0,
  hue: 0,
  sharpness: 0,
  clarity: 0,
  fade: 0,
  vignette: 0,
  grain: 0,
  blur: 0,
};

export const DEFAULT_GEOMETRY: GeometryTransform = {
  rotation: 0,
  flipH: false,
  flipV: false,
  crop: null,
  aspectRatio: 'original',
};

export const FILTER_PRESETS: FilterPreset[] = [
  {
    id: 'original',
    name: 'Original',
    nameHi: 'मूल (Original)',
    category: 'Creative',
    intensity: 100,
    thumbnailColor: '#64748b',
    adjustments: {},
  },
  {
    id: 'cinematic-teal',
    name: 'Cinematic Teal',
    nameHi: 'सिनेमैटिक टील',
    category: 'Cinematic',
    intensity: 85,
    thumbnailColor: '#0ea5e9',
    adjustments: {
      contrast: 22,
      saturation: -8,
      temperature: -14,
      tint: 12,
      highlights: -18,
      shadows: 16,
      vignette: 28,
      grain: 12,
      sharpness: 20,
    },
  },
  {
    id: 'golden-hour',
    name: 'Golden Hour',
    nameHi: 'गोल्डन ऑवर',
    category: 'Warm',
    intensity: 90,
    thumbnailColor: '#f59e0b',
    adjustments: {
      exposure: 6,
      contrast: 10,
      temperature: 32,
      tint: 8,
      vibrance: 22,
      highlights: -12,
      shadows: 15,
      vignette: 18,
    },
  },
  {
    id: 'portrait-soft',
    name: 'Portrait Soft Glow',
    nameHi: 'सॉफ्ट ग्लो पोर्ट्रेट',
    category: 'Portrait',
    intensity: 80,
    thumbnailColor: '#f43f5e',
    adjustments: {
      exposure: 12,
      contrast: -8,
      saturation: 8,
      temperature: 8,
      shadows: 24,
      whites: 12,
      clarity: 15,
      sharpness: 10,
    },
  },
  {
    id: 'vintage-film',
    name: 'Vintage 1980',
    nameHi: 'विंटेज 1980',
    category: 'Vintage',
    intensity: 85,
    thumbnailColor: '#d97706',
    adjustments: {
      contrast: 14,
      saturation: -18,
      temperature: 18,
      fade: 28,
      grain: 35,
      vignette: 32,
      highlights: -20,
    },
  },
  {
    id: 'bw-dramatic',
    name: 'B&W Dramatic',
    nameHi: 'ब्लैक एंड व्हाइट',
    category: 'B&W',
    intensity: 100,
    thumbnailColor: '#1e293b',
    adjustments: {
      saturation: -100,
      contrast: 38,
      highlights: 20,
      shadows: -18,
      clarity: 35,
      grain: 20,
      vignette: 22,
    },
  },
  {
    id: 'moody-noir',
    name: 'Moody Noir',
    nameHi: 'मूडी नवार',
    category: 'Moody',
    intensity: 85,
    thumbnailColor: '#334155',
    adjustments: {
      exposure: -12,
      contrast: 28,
      saturation: -30,
      shadows: -25,
      vignette: 45,
      fade: 14,
      sharpness: 24,
    },
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk Neon',
    nameHi: 'साइबरपंक नियॉन',
    category: 'Creative',
    intensity: 90,
    thumbnailColor: '#a855f7',
    adjustments: {
      contrast: 30,
      saturation: 35,
      temperature: -25,
      tint: 40,
      vignette: 30,
      clarity: 25,
      sharpness: 20,
    },
  },
  {
    id: 'emerald-forest',
    name: 'Emerald Forest',
    nameHi: 'एमराल्ड नेचर',
    category: 'Warm',
    intensity: 80,
    thumbnailColor: '#10b981',
    adjustments: {
      contrast: 18,
      vibrance: 25,
      tint: -22,
      temperature: -6,
      shadows: 14,
      highlights: -15,
      clarity: 20,
    },
  },
  {
    id: 'sunset-glow',
    name: 'Sunset Glow',
    nameHi: 'सनसेट ग्लो',
    category: 'Warm',
    intensity: 85,
    thumbnailColor: '#fb923c',
    adjustments: {
      exposure: 8,
      contrast: 16,
      temperature: 36,
      tint: 20,
      vibrance: 30,
      vignette: 20,
    },
  },
  {
    id: 'matte-editorial',
    name: 'Matte Editorial',
    nameHi: 'मैट एडिटोरियल',
    category: 'Portrait',
    intensity: 80,
    thumbnailColor: '#94a3b8',
    adjustments: {
      contrast: -5,
      saturation: -12,
      fade: 32,
      shadows: 20,
      highlights: -10,
      clarity: 18,
      grain: 15,
    },
  },
  {
    id: 'street-tokyo',
    name: 'Tokyo Night',
    nameHi: 'टोक्यो नाइट',
    category: 'Moody',
    intensity: 90,
    thumbnailColor: '#6366f1',
    adjustments: {
      exposure: -5,
      contrast: 32,
      saturation: 15,
      temperature: -18,
      tint: 15,
      clarity: 30,
      vignette: 25,
      sharpness: 25,
    },
  },
];

// Helper to load image cleanly
export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(new Error('Failed to load image: ' + err));
    img.src = src;
  });
}

// Full real-time canvas rendering pipeline
export function renderAdjustedImage(
  sourceCanvas: HTMLCanvasElement | HTMLImageElement,
  targetCanvas: HTMLCanvasElement,
  adjustments: ImageAdjustments,
  geometry: GeometryTransform,
  filterPreset?: FilterPreset,
  filterIntensity: number = 100,
  maskCanvas?: HTMLCanvasElement | null,
  options?: {
    scale?: number;
    backgroundStyle?: {
      type: 'none' | 'color' | 'gradient' | 'image';
      value?: string;
    };
  }
): void {
  // Combine adjustments with active filter weighted by intensity
  const merged: ImageAdjustments = { ...adjustments };
  if (filterPreset && filterPreset.id !== 'original') {
    const weight = (filterIntensity / 100) * (filterPreset.intensity / 100);
    for (const [k, v] of Object.entries(filterPreset.adjustments)) {
      const key = k as keyof ImageAdjustments;
      if (typeof v === 'number') {
        merged[key] = (merged[key] || 0) + v * weight;
      }
    }
  }

  const sWidth = sourceCanvas instanceof HTMLImageElement ? sourceCanvas.naturalWidth : sourceCanvas.width;
  const sHeight = sourceCanvas instanceof HTMLImageElement ? sourceCanvas.naturalHeight : sourceCanvas.height;

  // Determine crop box
  let cropX = 0;
  let cropY = 0;
  let cropW = sWidth;
  let cropH = sHeight;

  if (geometry.crop) {
    cropX = Math.max(0, geometry.crop.x);
    cropY = Math.max(0, geometry.crop.y);
    cropW = Math.min(sWidth - cropX, geometry.crop.width);
    cropH = Math.min(sHeight - cropY, geometry.crop.height);
  }

  // Target dimensions
  const scale = options?.scale || 1;
  const finalW = Math.max(1, Math.round(cropW * scale));
  const finalH = Math.max(1, Math.round(cropH * scale));

  targetCanvas.width = finalW;
  targetCanvas.height = finalH;

  const ctx = targetCanvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return;

  ctx.save();
  ctx.clearRect(0, 0, finalW, finalH);

  // Background replacement if requested
  if (options?.backgroundStyle && options.backgroundStyle.type !== 'none') {
    const bg = options.backgroundStyle;
    if (bg.type === 'color' && bg.value) {
      ctx.fillStyle = bg.value;
      ctx.fillRect(0, 0, finalW, finalH);
    } else if (bg.type === 'gradient' && bg.value) {
      const grad = ctx.createLinearGradient(0, 0, finalW, finalH);
      if (bg.value === 'sunset') {
        grad.addColorStop(0, '#f97316');
        grad.addColorStop(1, '#a855f7');
      } else if (bg.value === 'ocean') {
        grad.addColorStop(0, '#06b6d4');
        grad.addColorStop(1, '#3b82f6');
      } else if (bg.value === 'studio-dark') {
        grad.addColorStop(0, '#1e1b4b');
        grad.addColorStop(1, '#0f172a');
      } else {
        grad.addColorStop(0, '#3b82f6');
        grad.addColorStop(1, '#8b5cf6');
      }
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, finalW, finalH);
    }
  }

  // Center, rotate, and flip
  ctx.translate(finalW / 2, finalH / 2);
  if (geometry.rotation !== 0) {
    ctx.rotate((geometry.rotation * Math.PI) / 180);
  }
  ctx.scale(geometry.flipH ? -1 : 1, geometry.flipV ? -1 : 1);

  // Draw source image cropped
  ctx.drawImage(
    sourceCanvas,
    cropX, cropY, cropW, cropH,
    -finalW / 2, -finalH / 2, finalW, finalH
  );

  ctx.restore();

  // If there's an alpha mask (from background remover)
  if (maskCanvas) {
    ctx.globalCompositeOperation = 'destination-in';
    ctx.drawImage(maskCanvas, 0, 0, finalW, finalH);
    ctx.globalCompositeOperation = 'source-over';
  }

  // Pixel-level adjustments
  const imgData = ctx.getImageData(0, 0, finalW, finalH);
  applyPixelFilters(imgData, merged);
  ctx.putImageData(imgData, 0, 0);

  // Sharpening / convolution if > 0
  if (merged.sharpness > 0 || merged.clarity !== 0) {
    applyConvolutionSharpen(ctx, finalW, finalH, merged.sharpness, merged.clarity);
  }

  // Vignette effect
  if (merged.vignette > 0) {
    applyVignette(ctx, finalW, finalH, merged.vignette);
  }

  // Film grain effect
  if (merged.grain > 0) {
    applyFilmGrain(ctx, finalW, finalH, merged.grain);
  }
}

// Real pixel manipulation for 16 core tone/color parameters
function applyPixelFilters(imgData: ImageData, adj: ImageAdjustments): void {
  const d = imgData.data;
  const len = d.length;

  // Normalized factors
  const brightness = adj.brightness * 1.28; // -128 to 128
  const exposureFactor = Math.pow(2, adj.exposure / 25); // 0.25 to 4.0
  const contrastFactor = (259 * (adj.contrast + 255)) / (255 * (259 - adj.contrast)); // standard formula
  const satFactor = (adj.saturation + 100) / 100;
  const vibrance = adj.vibrance / 100;
  const temp = adj.temperature / 100;
  const tint = adj.tint / 100;
  const highlights = adj.highlights / 100;
  const shadows = adj.shadows / 100;
  const whites = adj.whites / 100;
  const blacks = adj.blacks / 100;
  const gamma = Math.pow(2, -adj.gamma / 50);
  const fade = (adj.fade / 100) * 45; // lifts shadows

  const tempR = temp > 0 ? 1 + temp * 0.35 : 1 + temp * 0.15;
  const tempB = temp < 0 ? 1 - temp * 0.35 : 1 - temp * 0.15;
  const tintG = tint < 0 ? 1 - tint * 0.25 : 1;
  const tintM = tint > 0 ? 1 + tint * 0.25 : 1;

  for (let i = 0; i < len; i += 4) {
    if (d[i + 3] === 0) continue; // transparent pixel

    let r = d[i];
    let g = d[i + 1];
    let b = d[i + 2];

    // Exposure
    if (adj.exposure !== 0) {
      r *= exposureFactor;
      g *= exposureFactor;
      b *= exposureFactor;
    }

    // Brightness
    if (brightness !== 0) {
      r += brightness;
      g += brightness;
      b += brightness;
    }

    // Contrast
    if (adj.contrast !== 0) {
      r = contrastFactor * (r - 128) + 128;
      g = contrastFactor * (g - 128) + 128;
      b = contrastFactor * (b - 128) + 128;
    }

    // Color Temperature & Tint
    if (temp !== 0) {
      r *= tempR;
      b *= tempB;
    }
    if (tint !== 0) {
      g *= tintG;
      r *= tintM;
      b *= tintM;
    }

    // Luminance & Tonal Adjustments (Highlights / Shadows / Whites / Blacks)
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    const normLum = lum / 255;

    if (highlights !== 0 && normLum > 0.5) {
      const hWeight = (normLum - 0.5) * 2;
      const boost = 1 + highlights * 0.4 * hWeight;
      r *= boost;
      g *= boost;
      b *= boost;
    }

    if (shadows !== 0 && normLum < 0.5) {
      const sWeight = (0.5 - normLum) * 2;
      const lift = shadows * 60 * sWeight;
      r += lift;
      g += lift;
      b += lift;
    }

    if (whites !== 0) {
      const wWeight = Math.pow(normLum, 2);
      r += whites * 40 * wWeight;
      g += whites * 40 * wWeight;
      b += whites * 40 * wWeight;
    }

    if (blacks !== 0) {
      const bWeight = Math.pow(1 - normLum, 2);
      r += blacks * 40 * bWeight;
      g += blacks * 40 * bWeight;
      b += blacks * 40 * bWeight;
    }

    // Film Fade (vintage black point lift)
    if (fade > 0) {
      r = r * (1 - fade / 255) + fade;
      g = g * (1 - fade / 255) + fade;
      b = b * (1 - fade / 255) + fade;
    }

    // Gamma
    if (adj.gamma !== 0) {
      r = 255 * Math.pow(Math.max(0, r / 255), gamma);
      g = 255 * Math.pow(Math.max(0, g / 255), gamma);
      b = 255 * Math.pow(Math.max(0, b / 255), gamma);
    }

    // Saturation & Vibrance
    const gray = 0.299 * r + 0.587 * g + 0.114 * b;
    if (satFactor !== 1) {
      r = gray + satFactor * (r - gray);
      g = gray + satFactor * (g - gray);
      b = gray + satFactor * (b - gray);
    }

    if (vibrance !== 0) {
      const maxC = Math.max(r, Math.max(g, b));
      const minC = Math.min(r, Math.min(g, b));
      const satVal = (maxC - minC) / (maxC + 0.001);
      const vibFactor = 1 + vibrance * (1 - satVal);
      r = gray + vibFactor * (r - gray);
      g = gray + vibFactor * (g - gray);
      b = gray + vibFactor * (b - gray);
    }

    d[i] = Math.max(0, Math.min(255, r));
    d[i + 1] = Math.max(0, Math.min(255, g));
    d[i + 2] = Math.max(0, Math.min(255, b));
  }
}

// 3x3 convolution for true sharpness & clarity
function applyConvolutionSharpen(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  sharpness: number,
  clarity: number
): void {
  const intensity = (sharpness / 100) * 0.8 + (Math.max(0, clarity) / 50) * 0.4;
  if (intensity <= 0.01) return;

  const src = ctx.getImageData(0, 0, w, h);
  const dst = ctx.createImageData(w, h);
  const s = src.data;
  const d = dst.data;

  // Unsharp mask kernel: [ 0, -k, 0; -k, 1+4k, -k; 0, -k, 0 ]
  const k = intensity;
  const center = 1 + 4 * k;

  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const idx = (y * w + x) * 4;
      const top = ((y - 1) * w + x) * 4;
      const bottom = ((y + 1) * w + x) * 4;
      const left = (y * w + (x - 1)) * 4;
      const right = (y * w + (x + 1)) * 4;

      for (let c = 0; c < 3; c++) {
        const val =
          s[idx + c] * center -
          (s[top + c] + s[bottom + c] + s[left + c] + s[right + c]) * k;
        d[idx + c] = Math.max(0, Math.min(255, val));
      }
      d[idx + 3] = s[idx + 3];
    }
  }

  ctx.putImageData(dst, 0, 0);
}

// Radial vignette
function applyVignette(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  amount: number
): void {
  const radius = Math.sqrt(w * w + h * h) / 2;
  const grad = ctx.createRadialGradient(
    w / 2, h / 2, radius * 0.35,
    w / 2, h / 2, radius
  );
  const alpha = (amount / 100) * 0.85;
  grad.addColorStop(0, 'rgba(0,0,0,0)');
  grad.addColorStop(1, `rgba(0,0,0,${alpha})`);

  ctx.save();
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);
  ctx.restore();
}

// Synthetic film grain
function applyFilmGrain(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  amount: number
): void {
  const grainCanvas = document.createElement('canvas');
  grainCanvas.width = 128;
  grainCanvas.height = 128;
  const gCtx = grainCanvas.getContext('2d');
  if (!gCtx) return;

  const gData = gCtx.createImageData(128, 128);
  const gd = gData.data;
  const strength = (amount / 100) * 55;

  for (let i = 0; i < gd.length; i += 4) {
    const noise = (Math.random() - 0.5) * strength;
    const v = 128 + noise;
    gd[i] = v;
    gd[i + 1] = v;
    gd[i + 2] = v;
    gd[i + 3] = 40;
  }
  gCtx.putImageData(gData, 0, 0);

  ctx.save();
  ctx.globalCompositeOperation = 'overlay';
  const pattern = ctx.createPattern(grainCanvas, 'repeat');
  if (pattern) {
    ctx.fillStyle = pattern;
    ctx.fillRect(0, 0, w, h);
  }
  ctx.restore();
}

// AI Background segmentation algorithm (color/luminance edge thresholding)
export function segmentForeground(
  canvas: HTMLCanvasElement,
  sensitivity: number = 0.5
): HTMLCanvasElement {
  const w = canvas.width;
  const h = canvas.height;
  const mask = document.createElement('canvas');
  mask.width = w;
  mask.height = h;
  const mCtx = mask.getContext('2d');
  const srcCtx = canvas.getContext('2d');
  if (!mCtx || !srcCtx) return mask;

  const srcData = srcCtx.getImageData(0, 0, w, h);
  const maskData = mCtx.createImageData(w, h);
  const s = srcData.data;
  const m = maskData.data;

  // Sample corner background colors (top-left, top-right, bottom-left)
  const corners = [0, (w - 1) * 4, ((h - 1) * w) * 4, ((h - 1) * w + (w - 1)) * 4];
  let bgR = 0, bgG = 0, bgB = 0;
  for (const c of corners) {
    bgR += s[c];
    bgG += s[c + 1];
    bgB += s[c + 2];
  }
  bgR /= corners.length;
  bgG /= corners.length;
  bgB /= corners.length;

  const threshold = (1 - sensitivity) * 80 + 35;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      const r = s[idx];
      const g = s[idx + 1];
      const b = s[idx + 2];

      // Euclidean color distance from background sample
      const dist = Math.sqrt(
        (r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2
      );

      // Center subject bias (humans/objects are usually centered in portraits)
      const dx = (x - w / 2) / (w / 2);
      const dy = (y - h / 2) / (h / 2);
      const centerDist = Math.sqrt(dx * dx + dy * dy);
      const centerBonus = Math.max(0, (1 - centerDist)) * 25;

      const score = dist + centerBonus;
      const alpha = score > threshold ? 255 : Math.max(0, Math.min(255, (score / threshold) * 255));

      m[idx] = 255;
      m[idx + 1] = 255;
      m[idx + 2] = 255;
      m[idx + 3] = alpha;
    }
  }

  mCtx.putImageData(maskData, 0, 0);
  return mask;
}

// Inpainting / Object eraser algorithm (diffusion patch interpolation)
export function inpaintMaskedArea(
  canvas: HTMLCanvasElement,
  brushMaskCanvas: HTMLCanvasElement
): void {
  const w = canvas.width;
  const h = canvas.height;
  const ctx = canvas.getContext('2d');
  const bCtx = brushMaskCanvas.getContext('2d');
  if (!ctx || !bCtx) return;

  const imgData = ctx.getImageData(0, 0, w, h);
  const maskData = bCtx.getImageData(0, 0, w, h);
  const d = imgData.data;
  const m = maskData.data;

  // 3-pass fast neighborhood content diffusion
  for (let pass = 0; pass < 3; pass++) {
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const idx = (y * w + x) * 4;
        if (m[idx + 3] > 30) {
          // Unwanted area: take average of surrounding unmasked pixels
          let sumR = 0, sumG = 0, sumB = 0, count = 0;
          const offsets = [-1, 1, -w, w, -w - 1, -w + 1, w - 1, w + 1];

          for (const off of offsets) {
            const nIdx = idx + off * 4;
            if (m[nIdx + 3] < 30) {
              sumR += d[nIdx];
              sumG += d[nIdx + 1];
              sumB += d[nIdx + 2];
              count++;
            }
          }

          if (count > 0) {
            d[idx] = sumR / count;
            d[idx + 1] = sumG / count;
            d[idx + 2] = sumB / count;
            m[idx + 3] = 0; // Mark resolved
          }
        }
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
}

// Portrait retouch (skin smoothing + eye detail boost)
export function applyPortraitRetouch(
  canvas: HTMLCanvasElement,
  intensity: number = 60
): void {
  const w = canvas.width;
  const h = canvas.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const imgData = ctx.getImageData(0, 0, w, h);
  const d = imgData.data;
  const factor = intensity / 100;

  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const idx = (y * w + x) * 4;
      const r = d[idx];
      const g = d[idx + 1];
      const b = d[idx + 2];

      // Skin tone detection in RGB
      const isSkin = r > 95 && g > 40 && b > 20 && r > g && r > b && (r - Math.min(g, b)) > 15;

      if (isSkin) {
        // Average with 4 neighbors to smooth texture while keeping color
        const top = ((y - 1) * w + x) * 4;
        const bottom = ((y + 1) * w + x) * 4;
        const left = (y * w + (x - 1)) * 4;
        const right = (y * w + (x + 1)) * 4;

        const avgR = (r + d[top] + d[bottom] + d[left] + d[right]) / 5;
        const avgG = (g + d[top + 1] + d[bottom + 1] + d[left + 1] + d[right + 1]) / 5;
        const avgB = (b + d[top + 2] + d[bottom + 2] + d[left + 2] + d[right + 2]) / 5;

        d[idx] = r * (1 - factor) + avgR * factor;
        d[idx + 1] = g * (1 - factor) + avgG * factor;
        d[idx + 2] = b * (1 - factor) + avgB * factor;
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
}
