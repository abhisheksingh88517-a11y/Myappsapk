import { ProjectState, ExportHistoryItem } from '../types';

const PROJECTS_KEY = 'pixora_projects_v2';
const EXPORTS_KEY = 'pixora_exports_v2';
const AUTOSAVE_KEY = 'pixora_autosave_v2';

export function getAllProjects(): ProjectState[] {
  try {
    const raw = localStorage.getItem(PROJECTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error('Failed to load projects from storage:', err);
    return [];
  }
}

export function saveProject(project: ProjectState): void {
  try {
    const existing = getAllProjects();
    const index = existing.findIndex((p) => p.id === project.id);
    if (index >= 0) {
      existing[index] = { ...project, updatedAt: Date.now() };
    } else {
      existing.unshift({ ...project, updatedAt: Date.now() });
    }
    // Limit to latest 15 projects to prevent LocalStorage quota overflow
    const trimmed = existing.slice(0, 15);
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(trimmed));
  } catch (err) {
    console.error('Failed to save project:', err);
  }
}

export function deleteProject(id: string): void {
  try {
    const existing = getAllProjects();
    const updated = existing.filter((p) => p.id !== id);
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to delete project:', err);
  }
}

export function saveAutoSaveState(project: ProjectState): void {
  try {
    localStorage.setItem(AUTOSAVE_KEY, JSON.stringify(project));
  } catch (err) {
    // Ignore quota issues for autosave
  }
}

export function getAutoSaveState(): ProjectState | null {
  try {
    const raw = localStorage.getItem(AUTOSAVE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (err) {
    return null;
  }
}

export function getAllExports(): ExportHistoryItem[] {
  try {
    const raw = localStorage.getItem(EXPORTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    return [];
  }
}

export function saveExportItem(item: ExportHistoryItem): void {
  try {
    const existing = getAllExports();
    existing.unshift(item);
    const trimmed = existing.slice(0, 20);
    localStorage.setItem(EXPORTS_KEY, JSON.stringify(trimmed));
  } catch (err) {
    console.error('Failed to save export history:', err);
  }
}

export function deleteExportItem(id: string): void {
  try {
    const existing = getAllExports();
    const updated = existing.filter((e) => e.id !== id);
    localStorage.setItem(EXPORTS_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to delete export item:', err);
  }
}
