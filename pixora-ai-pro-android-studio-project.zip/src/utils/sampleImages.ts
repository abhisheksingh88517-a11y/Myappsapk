export interface SampleImage {
  id: string;
  title: string;
  category: 'Portrait' | 'Landscape' | 'Street' | 'Fashion' | 'Night';
  url: string;
  width: number;
  height: number;
}

export const SAMPLE_IMAGES: SampleImage[] = [
  {
    id: 'sample-portrait-1',
    title: 'Studio Portrait',
    category: 'Portrait',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80',
    width: 1200,
    height: 1600,
  },
  {
    id: 'sample-street-1',
    title: 'Neon Tokyo Street',
    category: 'Street',
    url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1200&q=80',
    width: 1200,
    height: 1500,
  },
  {
    id: 'sample-landscape-1',
    title: 'Golden Mountain Lake',
    category: 'Landscape',
    url: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1200&q=80',
    width: 1200,
    height: 800,
  },
  {
    id: 'sample-fashion-1',
    title: 'Editorial Fashion',
    category: 'Fashion',
    url: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=80',
    width: 1200,
    height: 1600,
  },
  {
    id: 'sample-night-1',
    title: 'Cyberpunk Skyline',
    category: 'Night',
    url: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1200&q=80',
    width: 1200,
    height: 800,
  },
];
